#include "motor.h" 
#include "flash.h"
#include "delay.h"



uint16_t Flash_Read(uint32_t address)
{
	return *(__IO uint16_t*)(start_sddress+address*1024);
}
uint32_t Flash_ReadWord(uint32_t address)
{
	uint32_t temp1,temp2;
	temp1=	*(__IO uint16_t*)(start_sddress+address*1024);
	temp2=	*(__IO uint16_t*)(start_sddress+(address*1024)+2);
	return (temp2<<16)+temp1;
}

void Flash_wirte(uint16_t ADDR,uint8_t *buff,uint8_t Word_flag)
{
	uint8_t status;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	if(FLASH_ErasePage(start_sddress+ADDR*1024)==FLASH_COMPLETE)
	{
		if(Word_flag==Word)
		{
			 status=FLASH_ProgramWord(start_sddress+ADDR*1024,buff[3]<<24|buff[2]<<16|buff[1]<<8|buff[0]);
		}
		else if(Word_flag==Half_Word)
				FLASH_ProgramHalfWord(start_sddress+ADDR*1024,	(uint16_t)buff[0]|buff[1]<<8);
		
				delay_ms(1);
	}
	FLASH_Lock();
}


void Set_Protection()
{	
	if(FLASH_GetReadOutProtectionStatus() != SET)
	{
		FLASH_Unlock();
		FLASH_ReadOutProtection(ENABLE);
		FLASH_Lock();
	}
}
void Reset_Protection()
{
	if(FLASH_GetReadOutProtectionStatus() != RESET)
	{
		FLASH_Unlock();
		FLASH_ReadOutProtection(DISABLE);
		FLASH_Lock();
	}
}
