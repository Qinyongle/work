#ifndef _gps_h_
#define _gps_h_
#include "stdint.h"
#define PI 3.1415926
#define R 6371

#define Flash_Lat_Addr 2
#define Flash_Lng_Addr 3

#define sCourseError 3.0f

#define DATA_TRUE_COUNT 20


extern double lng1,lat1,lng2,lat2;
extern double sCourse,tCourse,aCourse,zDegree,deltaDegree;
uint8_t Getgps(uint8_t *p,uint8_t sta);
double get_angle(double AW, double Aj, double BW, double Bj);
uint8_t SetOppositeGps(uint8_t *p);
void ReadGps(void);
void Write_Coordinates(double AW,double AJ);
void Read_Coordinates(double *AW,double *AJ);
uint8_t  isConnected(void);
#endif
