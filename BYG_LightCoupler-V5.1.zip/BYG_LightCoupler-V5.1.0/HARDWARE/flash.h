#ifndef _flash_h_
#define _flash_h_
#include "stm32f10x_flash.h"
#define start_sddress     0x801E000			//�洢��ʼ��ַ

void Flash_wirte(uint16_t ADDR,uint8_t *buff,uint8_t Word_flag);
uint32_t Flash_ReadWord(uint32_t address);
uint16_t Flash_Read(uint32_t address);
void Set_Protection(void);
void Reset_Protection(void);

enum Word_E
{
	Word= 0,
	Half_Word
};
#endif
