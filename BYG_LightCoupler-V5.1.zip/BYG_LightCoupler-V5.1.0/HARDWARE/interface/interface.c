#include "interface.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "motor.h"
#include "light_Coupler.h"
#include "gps.h"
uint8_t temp_buffer[TEMP_SIZE]={0};
uint8_t lora_address[]={0x00,0x0A,0x0a};

double longitude=0,latitude=0;
uint8_t lat_status=0,long_status=0;
float azimuth_Angle=0;



uint8_t Log=0;
uint8_t GpsLog=0;
uint8_t Usart1Log=0;
uint8_t CouplerLog=0;
uint16_t GetGpsFlag=1;
void send_ToLora(uint8_t *str)
{
		printf("%s",lora_address);   
		printf("%s\r\n",str);
		USARTN=USART2;
}
void lora()
{
	USARTN=USART1;
	printf("%s",lora_address); 
}


void Usart2_Process()
{
	uint16_t Speed;
	double angle=0;
	int32_t deltaAngle;
	uint32_t mode;
	if(USART2_RX_STA&0x8000)
	{
		 USARTN=USART2;
		
		 if(USART2_RX_BUF[0] == 'A' && strchr((char*)USART2_RX_BUF, 'B') != NULL)		
		{
//			if(motor.Cal_Pulse==0)					//�жϵ���Ƿ��Ѿ�ת��Ŀ��λ��
//			{
					angle=atof((const char*)USART2_RX_BUF+1);				//�ַ���ת���ɸ���������	
					motor.Target_Pulse	=	((angle*10)/STEP_ANGLE);		//����Ƕ�����Ҫ��������
					if((motor.Target_Pulse%10)>=5)																		//��������
					{
						motor.Target_Pulse	=((motor.Target_Pulse+10)/10);
					}
					else
					{
						motor.Target_Pulse = (motor.Target_Pulse/10);
					}
					//angle=CompensateAngle(motor.Target_Pulse*STEP_ANGLE);
					
					printf("tarAngle=%lf\r\n",angle);
					motor.Target_Pulse=angle/STEP_ANGLE;

					deltaAngle=motor.Target_Pulse-motor.Current_Pulse;
					if(deltaAngle>OneCircleNums>>1)
					{
						deltaAngle -=OneCircleNums;
					}
					else if(deltaAngle<-OneCircleNums>>1)
					{
						deltaAngle +=OneCircleNums;
					}
				//	printf("Angle=%lf,motor.Target_Pulse=%d,motor.Current_Pulse=%d\r\n",deltaAngle*STEP_ANGLE,motor.Target_Pulse,motor.Current_Pulse);
				
					if(deltaAngle>0)
					{
						SET_LEFT;	
						motor.Direction=1;
					}
					else if(deltaAngle<0)
					{
						SET_RIGHT;	
						motor.Direction=-1;
					}
			//	}
		}
	 else if(strstr((char*)USART2_RX_BUF, "ReadGps") != NULL)					//��Gps
		{
				ReadGps();
		}
		else  if(strstr((char*)USART2_RX_BUF, "SET") != NULL)						//���öԷ���γ��
		{
			if(SetOppositeGps(USART2_RX_BUF)==1)
			{
				Write_Coordinates(lat2,lng2);				//�������õľ�γ��
				Read_Coordinates(&lat2,&lng2);
				printf("ln1=%lf,la1=%lf,ln2=%lf,la2=%lf\r\n",lng1,lat1,lng2,lat2);
				//printf("Set Success\r\n");
			}
			else
			{
				printf("Set Fail\r\n");
			}
		}
		else if(strstr((char*)USART2_RX_BUF, "Speed") != NULL)							//�޸��ٶ�
		{
			Speed=Strtin(USART2_RX_BUF);			//�ַ�����������
			if(Speed<0xffff)
			{
					TIM2->ARR=Speed;
					Flash_wirte(5,(uint8_t *)&Speed,Half_Word);
					printf("Done\r\n");
			}
		}
		else if(strstr((char*)USART2_RX_BUF, "Reset") != NULL)							
		{
				NVIC_SystemReset();
		}
		else if(strstr((char*)USART2_RX_BUF, "Compensation") != NULL)					//���ò�����
		{
			sscanf((char*)USART2_RX_BUF,"Compensation%lf",&compensateAngle);
			writeCompensation(compensateAngle);
			readCompensation(&compensateAngle);
			printf("Compensation%lf\r\n",compensateAngle);
		}
		else if(strstr((char*)USART2_RX_BUF, "ReadCompensation") != NULL)		//��������
		{
			printf("Compensation%lf\r\n",compensateAngle);
		}
		else if(strstr((char*)USART2_RX_BUF, "logon") != NULL)							
		{
				Log=1;printf("Log=%d\r\n",Log);
		}
		else if(strstr((char*)USART2_RX_BUF, "logoff") != NULL)							
		{
				Log=0;
			printf("Log=%d\r\n",Log);
		}
		else if(strstr((char*)USART2_RX_BUF, "GpsLogon") != NULL)							
		{
				GpsLog=1;
			
			Flash_wirte(5,(uint8_t *)&Speed,Half_Word);
		}
		else if(strstr((char*)USART2_RX_BUF, "GpsLogoff") != NULL)							
		{
				GpsLog=0;
		}
		else if(strstr((char*)USART2_RX_BUF, "UsarLogon") != NULL)							
		{
				Usart1Log=1;
		}
		else if(strstr((char*)USART2_RX_BUF, "UsarLogoff") != NULL)							
		{
				Usart1Log=0;
		}
		else  if(strstr((char*)USART2_RX_BUF, "message") != NULL)				
		{
			printf("BOARD:%s\r\n",BOARD);
			printf("Bootloader:%s\r\n",Bootloader);
			printf("VERSION:%s\r\n",VERSION);
			printf("TIME:%s\r\n",TIME);
		}
		else  if(strstr((char*)USART2_RX_BUF, "CouplerOn") != NULL)				
		{
				CouplerLog=1;
			printf("CouplerLog=%d\r\n",CouplerLog);
		}
		else  if(strstr((char*)USART2_RX_BUF, "CouplerOff") != NULL)				
		{
				CouplerLog=0;
		}
		else  if(strstr((char*)USART2_RX_BUF, "GetGpsOn") != NULL)				
		{
			GetGpsFlag=1;
			GetGpsFlag=(GetGpsFlag<<15)|MORTOR_MAX_SPEED_LIMIT;
			Flash_wirte(5,(uint8_t *)&GetGpsFlag,Half_Word);
			GetGpsFlag=1;
		}
		else  if(strstr((char*)USART2_RX_BUF, "GetGpsOff") != NULL)				
		{
			GetGpsFlag=0;
			GetGpsFlag=(GetGpsFlag<<15)|MORTOR_MAX_SPEED_LIMIT;
			Flash_wirte(5,(uint8_t *)&GetGpsFlag,Half_Word);
			GetGpsFlag=0;
		}
		else  if(strstr((char*)USART2_RX_BUF, "BUG") != NULL)				
		{
			printf("BUG=%d\r\n",BUG);
		}
		else if(strstr((char*)USART2_RX_BUF, "Apploade") != NULL)
		{
			Flag_Update=0x66;							//��������±�־λ��0x66,��Bootloade�������б���Ҫ���³���
			Flash_wirte(Flag_Update_Addr,(u8 *)&Flag_Update,Half_Word);	//���浱ǰ��־λ
			Flag_Update_App=0;
			Flash_wirte(Flag_Updata_APP_Addr,(u8*)&Flag_Update_App,Half_Word);
														//�˳���ǰwhileѭ��
			NVIC_SystemReset();
		}
		USART2_RX_STA	=	0;																								//����ձ�־λ
		memset(USART2_RX_BUF,0,strlen((const char*)USART2_RX_BUF));										//�建����
	}
}
void Usart_Process()
{
	uint16_t Speed=0;
	double angle=0;
	int32_t deltaAngle;
	int UsartNum=1;
	if(USART_RX_STA&0x8000)
	{
		if(Usart1Log==1)
		{
			USARTN=USART2;
			printf("%s\r\n",USART_RX_BUF);
		}
 if(USART_RX_BUF[0] == 'A' && strchr((char*)USART_RX_BUF, 'B') != NULL)		
		{
			if(motor.Cal_Pulse==0)					//�жϵ���Ƿ��Ѿ�ת��Ŀ��λ��
			{
					angle=atof((const char*)USART_RX_BUF+1);				//�ַ���ת���ɸ���������	
					motor.Target_Pulse	=	((angle*10)/STEP_ANGLE);		//����Ƕ�����Ҫ��������
					if((motor.Target_Pulse%10)>=5)																		//��������
					{
						motor.Target_Pulse	=((motor.Target_Pulse+10)/10);
					}
					else
					{
						motor.Target_Pulse = (motor.Target_Pulse/10);
					}
				//angle=CompensateAngle(motor.Target_Pulse*STEP_ANGLE);
					
					printf("angle=%lf\r\n",angle);
					motor.Target_Pulse=angle/STEP_ANGLE;

					deltaAngle=motor.Target_Pulse-motor.Current_Pulse;
					if(deltaAngle>OneCircleNums>>1)
					{
						deltaAngle -=OneCircleNums;
					}
					else if(deltaAngle<-OneCircleNums>>1)
					{
						deltaAngle +=OneCircleNums;
					}
					printf("Angle=%lf,motor.Target_Pulse=%d,motor.Current_Pulse=%d\r\n",deltaAngle*STEP_ANGLE,motor.Target_Pulse,motor.Current_Pulse);
					if(deltaAngle>0)
					{
						SET_LEFT;	
						motor.Direction=1;
					}
					else if(deltaAngle<0)
					{
						SET_RIGHT;	
						motor.Direction=-1;
						motor.Pulse_Inground=0;
						RefreshAngle();
					}
				}
		}
		else if(strstr((char*)USART_RX_BUF, "Cordinate") != NULL)					//�����յ��ľ�γ����Ϣ
		{
			if(GetGpsFlag)
			{
					if(Getgps(USART_RX_BUF,0)==1)			//����������ȷִ��
					{
						antTracker();
					}
			}
		}
		else if(strstr((char*)USART_RX_BUF, "Speed") != NULL)							//�޸��ٶ�
		{
			Speed=Strtin(USART_RX_BUF);			//�ַ�����������
			if(Speed<0xffff)
			{
					TIM2->ARR=Speed;
					//Flash_wirte(2,(uint8_t *)&Speed,Half_Word);
					printf("Done\r\n");
			}
		}
		else if(strstr((char*)USART_RX_BUF, "Reset") != NULL)							
		{
				NVIC_SystemReset();
		}
		else  if(strstr((char*)USART_RX_BUF, "sCourse") != NULL)
		{
			sscanf((const char*)USART_RX_BUF,"sCourse%lf",&sCourse);
		}
		else  if(strstr((char*)USART_RX_BUF, "tCourse") != NULL)
		{
			sscanf((const char*)USART_RX_BUF,"tCourse%lf",&tCourse);
		}
		else  if(strstr((char*)USART_RX_BUF, "GPGGA") != NULL&&strstr((char*)USART_RX_BUF, "HEADINGA") != NULL)
		{
			if(GetGpsFlag==1)
			{
				if(Getgps(USART_RX_BUF,1)==1)			//����������ȷִ��
					{
						antTracker();
					}
			}
		}
		USART_RX_STA	=	0;																								//����ձ�־λ
		memset(USART_RX_BUF,0,strlen((const char*)USART_RX_BUF));										//�建����
	}   
}


void onusart()
{
	Usart_Process();
	Usart2_Process();
}
