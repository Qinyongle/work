#ifndef __DELAY_H
#define __DELAY_H 			   
//#include "sys.h"  
#include <stm32f10x.h>
	 
void DelayInit(void);


#endif





























