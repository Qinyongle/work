#ifndef _interface_h_
#define _interface_h_

#include "main.h"
#define WRITE GPIO_PIN_SET
#define READ 	GPIO_PIN_RESET
#define Locupler_STATUS(n) HAL_GPIO_WritePin(RS485_CH_GPIO_Port,RS485_CH_Pin,n)


#define BUFFER_SIZE  300
#define TEMP_SIZE 50

#define long_start	17
#define long_num		15

#define lat_start	32
#define lat_num 16

#define Frame_Length 
void onusart();
void Usart_Process(void);
unsigned char isConnected(void);
void send_ToLora(unsigned char *str);
#endif
