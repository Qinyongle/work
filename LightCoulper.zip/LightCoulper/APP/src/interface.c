#include "interface.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "light_Coupler.h"
uint8_t temp_buffer[TEMP_SIZE]={0};
uint8_t lora_address[]={0xff,0xff,0x0e};

double longitude=0,latitude=0;
uint8_t lat_status=0,long_status=0;
float azimuth_Angle=0;

//enum MODE motorMode=checkMode;

uint8_t isConnected()
{
	static uint8_t times=0;
	if(rx_end_flag==1)
	{
		if(strstr((const char*)rx_buff,"$GPGGA")!=NULL&&strstr((const char*)rx_buff,"#HEADINGA")!=NULL)
		{
			times++;
		}
		rx_end_flag=0;
		memset(rx_buff,0,strlen((const char*)rx_buff));	
	}
	if(times>10)
	{
		return 1;
	}
	else return 0;
}

void Usart_Process()
{
	if(rx_end_flag==1)
	{
			rx_end_flag=0;
			if(strstr((const char*)rx_buff,"ReadAngle")!=NULL)
			{
				printf("Angle=%lf\r\n",curentPosion);
			}
		else	if(strstr((const char*)rx_buff,"CheckMode")!=NULL)
			{
				Locupler_STATUS(WRITE);
				LcMode=Check;
				HAL_Delay(1000);
				printf("CheckMode Start\r\n");
				Locupler_STATUS(READ);
			}
		else	if(strstr((const char*)rx_buff,"ScanMode")!=NULL)
			{
				LcMode=Scan;
			}
			Rx_count=0;		
			memset(rx_buff,0,strlen((const char*)rx_buff));
	}
}

//void onusart()
//{
//	switch(motorMode)
//	{
//		case checkMode:
//		{
//			if(angleRef()==1)motorMode=ScanMode;
//		}break;
//		case ScanMode:
//		{
//			Usart_Process();
//		}break;

//}