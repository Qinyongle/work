#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"
#include <stdio.h>
#include <stdio.h>
#include "stdbool.h"
#include "led.h"
#include "flash.h"

#define Motor_31sub  1						//����������
#define Motor_5_18sub 0						//�ĸ�С��ת̨


#define Flag_Update_Addr   0x801E000			//���±�־λ��ַ

#define Flag_Updata_APP_Addr   0x801E400	//������±�־��ַ



#define ENABLEPORT	GPIOA								//ʹ��IO��
#define ENABLEPIN		GPIO_Pin_6

#define DIRECTIONPORT		GPIOA						//�������IO��
#define DIRECTIONPIN		GPIO_Pin_5

#define CLKPORT		GPIOA									//����IO��
#define CLKPIN		GPIO_Pin_4

#define RESET_MOTOR GPIO_ResetBits(ENABLEPORT,ENABLEPIN)
#define SET_MOTOR   GPIO_SetBits(ENABLEPORT,ENABLEPIN)

#define EN_Motor GPIO_ResetBits(ENABLEPORT,ENABLEPIN)
#define DIS_Motor GPIO_SetBits(ENABLEPORT,ENABLEPIN)

#if Motor_31sub
#define SET_RIGHT GPIO_SetBits(DIRECTIONPORT,DIRECTIONPIN)				//1:31���
#define SET_LEFT  GPIO_ResetBits(DIRECTIONPORT,DIRECTIONPIN)
#endif

#if Motor_5_18sub
#define SET_RIGHT GPIO_ResetBits(DIRECTIONPORT,DIRECTIONPIN)				//1:5.18���
#define SET_LEFT  GPIO_SetBits(DIRECTIONPORT,DIRECTIONPIN)
#endif

typedef struct
{
		float kp;
		float	ki;
		float	kd;
		int32_t Error, ErrorLast;
		int32_t outputKp, outputKi, outputKd;
		int32_t integralRound;
		int32_t integralRemainder;
		int32_t output;
} PID_t;
typedef struct
{
	uint32_t Current_Pulse;
	uint32_t est_Pulse;
	uint32_t Current_Position;
	uint32_t Target_Pulse;
	uint32_t Cal_Pulse;
	uint32_t Pulse_Inground;
	uint16_t Motor_Speed;
	int16_t  Goal_Speed;
	int8_t  Direction;
	uint8_t Fixed;
	uint8_t Calibrate;
}MOTOR;

extern MOTOR motor;
extern 	PID_t location;
#if Motor_31sub
#define STEP_ANGLE					0.0024193548387097f		//1:31���ٱȵ�������ִ�����1:3,8ϸ��
#define STEP_Pulse_Motor    1
#define OneCircleNums	 			148800								//��̨תһȦ�ܹ���Ҫ��������


#define MORTOR_MAX_SPEED_LIMIT 64
#define MORTOR_MIN_SPEED_LIMIT 256

#define DEADSPACE  0.5f/STEP_ANGLE 

#define Aceel_Num  2.0f/STEP_ANGLE
#endif

#if Motor_5_18sub
#define STEP_ANGLE					0.0144787644787645f		//1:5.18���ٱȵ�������ִ�����1:3,8ϸ��
#define STEP_Pulse_Motor    1
#define OneCircleNums	 			24864								//��̨תһȦ�ܹ���Ҫ��������

#endif


//#define kp 0.7
//#define ki 0.04
	
#define limitCompensate  90



extern int32_t incrementAngle;
extern double compensateAngle;
extern u16 Flag_Update,Flag_Update_App;
void motor_GpioInit(void);
void motorPower_PowerSLine(uint16_t Fre[], int len, int FStart, int FStop, int flexible);
void check_Origin(void);
void piLoop(uint32_t TarAngle);
void Check_StepAngle(void);
void RefreshAngle(void);
void antTracker(void);
double CompensateAngle(double angle);
void writeCompensation(double Comp);
void readCompensation(double *Comp);
void 	motorLog(void);
void Cal_Speed(int16_t goal);
void pid_Speed(int32_t Input,int32_t actualSpeed);
void pid_Init();
#endif
