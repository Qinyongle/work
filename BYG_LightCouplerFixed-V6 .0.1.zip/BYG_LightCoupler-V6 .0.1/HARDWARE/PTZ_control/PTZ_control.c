#include "PTZ_control.h"
#include "usart.h"
#include <string.h>
#include <stdlib.h>
#include "motor.h" 




#define ADDR 1
#define STEP_ANGLE 0.03846154  //�����1���Ķ���

char checkSum(char buf[])
{
    char sum =0;
		char i;
	
    for(i = 1;i < 6;i++)
    {
        sum += buf[i];
    }
		
    return sum;
}


//void Show_horizontal_angle(int16_t step)
//{
//		int n = 0;
//	
//		char buf[7] = {0};
//		
//		n = step * STEP_ANGLE * 10;
//		if(n%10 >4)
//		{
//			n = n/10 + 1;
//		}
//		else
//		{
//			n = n/10;
//		}
//		
//		n = n * 100;
//		
//		buf[0] = 0xFF;
//		buf[1] = ADDR;
//		buf[2] = 0;
//		buf[3] = 0x59;
//		buf[5] = n;
//		buf[4] = n >> 8;
//		
//		buf[6] = checkSum(buf);
//		
//		USART_ReceiveData(USART1);
//		
//		for(n = 0;n <= 6;n++)
//		{
//			while(!(USART1->ISR&(0X01<<7)));
//			USART1->TDR=buf[n];
//		}

//		
//}


//void Show_vertical_angle(int16_t step)
//{
//		int n = 0;
//	
//		char buf[7] = {0};
//		
//		n = step * STEP_ANGLE * 10;
//		if(n%10 >4)
//		{
//			n = n/10 + 1;
//		}
//		else
//		{
//			n = n/10;
//		}
//		n = n * 100;

//		buf[0] = 0xFF;
//		buf[1] = ADDR;
//		buf[2] = 0;
//		buf[3] = 0x5B;
//		buf[5] = n;
//		buf[4] = n >> 8;
//		
//		buf[6] = checkSum(buf);
//		
//		USART_ReceiveData(USART1);
//		
//		for(n = 0;n <= 6;n++)
//		{
//			while(!(USART1->ISR&(0X01<<7)));
//			USART1->TDR=buf[n];
//		}

//}

int16_t RX_data(void)
{
	
	if(USART_RX_BUF[0] != 0XFF || USART_RX_BUF[1] != ADDR || USART_RX_BUF[2] != 0X0 || USART_RX_BUF[6] != checkSum(USART_RX_BUF))
	{
		return -1;
	}
//	
//	if(USART_RX_BUF[3] == 0x51)
//	{
//		Show_horizontal_angle(Horizontal_Current_step);
//	}
//	else if(USART_RX_BUF[3] == 0x53)
//	{
//		Show_vertical_angle(Vertical_Current_step);
//	}
	//ָ��� �������ˮƽ�ĵ����ָ��Ҳȥ���ƴ�ֱ�ĵ��
//	if(USART_RX_BUF[3] == 0X04)
//	{
//		USART_RX_BUF[3] = 0X10;
//	}
//	
//	if(USART_RX_BUF[3] == 0X02)
//	{
//		USART_RX_BUF[3] = 0X08;
//	}
//	
//	if(USART_RX_BUF[3] == 0X4B)
//	{
//		USART_RX_BUF[3] = 0X4D;
//	}
	
	
	
	if(USART_RX_BUF[3] == 0x4B)
	{
		//Horizontal_Data_processing();
		return 0;
	}
	else if(USART_RX_BUF[3] == 0x4D)
	{
//		Vertical_Data_processing();
		return 0;
	}
	else if(USART_RX_BUF[3] == 0x02 && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//ˮƽ��ת
	{
		
//		if(self_test & 0x1<<0)
//		{
//			self_test &= ~(0x1<<0);
//		}
//		
//		if(self_test & 0x1<<1)
//		{
//			return -1;
//		}
			
		
		Horizontal_Angle = 0x1;
		return 0;
	}
	else if(USART_RX_BUF[3] == 0x04 && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//ˮƽ��ת
	{
//		if(self_test & 0x1<<1)
//		{
//			self_test &= ~(0x1<<1);
//		}
//		if(self_test & 0x1<<0)
//		{
//			return -1;
//		}
		

			
		Horizontal_Angle = 0x2;
		return 0;
	}
//	else if(USART_RX_BUF[3] == 0x08 && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//��ֱ��ת
//	{
////		if(self_test & 0x1<<3)
////		{
////			self_test &= ~(0x1<<3);
////		}
////		if(self_test & 0x1<<2)
////		{
////			return -1;
////		}
//			

////		Vertical_Angle = 0x1;
//		return 0;
//	}
//	else if(USART_RX_BUF[3] == 0x10 && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//��ֱ��ת
//	{
////		if(self_test & 0x1<<2)
////		{
////			self_test &= ~(0x1<<2);
////		}
////		
////		
////		if(self_test & 0x1<<3)
////		{
////			return -1;
////		}
//		


////		Vertical_Angle = 0x2;
//		return 0;
//	}
//	else if(USART_RX_BUF[3] == 0x0A && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//����
//	{
//			
////		if(self_test & 0x1<<0)
////		{
////			self_test &= ~(0x1<<0);
////		}
////		
////		if(self_test & 0x1<<3)
////		{
////			self_test &= ~(0x1<<3);
////		}
////		
////		if(self_test & 0x1<<1)
////		{
////			Horizontal_Angle = 0x0;
////		}
////		else
////		{
////			Horizontal_Angle = 0x1;
////		}
//		
////		if(self_test & 0x1<<2)
////		{
////			Vertical_Angle = 0x0;
////		}
////		else
////		{
////			Vertical_Angle = 0x1;
////		}
//		
//		
//		return 0;
//	}
//	
//	else if(USART_RX_BUF[3] == 0x12 && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//����
//	{
//		if(self_test & 0x1<<0)
//		{
//			self_test &= ~(0x1<<0);
//		}
//		
//		if(self_test & 0x1<<2)
//		{
//			self_test &= ~(0x1<<2);
//		}
//		
//		if(self_test & 0x1<<1)
//		{
//			Horizontal_Angle = 0x0;
//		}
//		else
//		{
//			Horizontal_Angle = 0x1;
//		}
//		
////		if(self_test & 0x1<<3)
////		{
////			Vertical_Angle = 0x0;
////		}
////		else
////		{
////			Vertical_Angle = 0x2;
////		}
//		
////		Horizontal_Angle = 0x1;
////		Vertical_Angle = 0x2;
//		return 0;
//	}
//	else if(USART_RX_BUF[3] == 0x0C && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//����
//	{
//		if(self_test & 0x1<<1)
//		{
//			self_test &= ~(0x1<<1);
//		}
//		
//		if(self_test & 0x1<<3)
//		{
//			self_test &= ~(0x1<<3);
//		}
//		
//		if(self_test & 0x1<<0)
//		{
//			Horizontal_Angle = 0x0;
//		}
//		else
//		{
//			Horizontal_Angle = 0x2;
//		}
//		
////		if(self_test & 0x1<<2)
////		{
////			Vertical_Angle = 0x0;
////		}
////		else
////		{
////			Vertical_Angle = 0x1;
////		}
//		
////		
////		Horizontal_Angle = 0x2;
////		Vertical_Angle = 0x1;
//		return 0;
//	}
//	else if(USART_RX_BUF[3] == 0x14 && USART_RX_BUF[4] == 0x20 && USART_RX_BUF[5] == 0x20)//����
//	{
//		if(self_test & 0x1<<1)
//		{
//			self_test &= ~(0x1<<1);
//		}
//		
//		if(self_test & 0x1<<2)
//		{
//			self_test &= ~(0x1<<2);
//		}
//		
//		if(self_test & 0x1<<0)
//		{
//			Horizontal_Angle = 0x0;
//		}
//		else
//		{
//			Horizontal_Angle = 0x2;
//		}
//		
////		if(self_test & 0x1<<3)
////		{
////			Vertical_Angle = 0x0;
////		}
////		else
////		{
////			Vertical_Angle = 0x2;
////		}
////		Horizontal_Angle = 0x2;
////		Vertical_Angle = 0x2;
//		return 0;
//	}
	else
	{
		return -1;
	}
	

}
