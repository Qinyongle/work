#ifndef _interface_h_
#define _interface_h_
#include "stdint.h"
#define BUFFER_SIZE  300
#define TEMP_SIZE 50

#define long_start	17
#define long_num		14

#define lat_start	32
#define lat_num 15
void onusart(void);
void Usart_Process(void);
void Usart3_Process(void);
void send_ToLora(uint8_t *str);
extern uint8_t Log,GpsLog,CouplerLog,GetGpsFlag;
#endif
