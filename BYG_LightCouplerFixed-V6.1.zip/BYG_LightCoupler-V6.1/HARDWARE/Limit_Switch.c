#include "limit_switch.h"
#include "delay.h"
LS LS_RIGHT={LIMIT_PORT,LIMIT_PIN1},LS_LEFT={LIMIT_PORT,LIMIT_PIN0};

void Limit_Switch_Init()
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	 GPIO_InitStructure.GPIO_Pin = LS_RIGHT.GPIO_Pin_x|LS_LEFT.GPIO_Pin_x;				 //PC0��PC1����
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 			//��������
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	 GPIO_Init(LS_RIGHT.GPIOx, &GPIO_InitStructure);				
	 
}

STATUS LS_STATUS_READ(LS *p)
{
	if(GPIO_ReadInputDataBit(p->GPIOx,p->GPIO_Pin_x)==RESET)
	{
		delay_ms(10);
		if(GPIO_ReadInputDataBit(p->GPIOx,p->GPIO_Pin_x)==RESET)
		return ON;
	}
	else if(GPIO_ReadInputDataBit(p->GPIOx,p->GPIO_Pin_x)==SET)
	{
		delay_ms(10);
		if(GPIO_ReadInputDataBit(p->GPIOx,p->GPIO_Pin_x)==SET)
		return OFF;
	}
}




