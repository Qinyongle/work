#include "Dog.h"
#include "sys.h"
#include "cevent.h"
#include "cpost.h"
#include "myevent.h"

CEVENT_EXPORT(EVENT_AFTER_CHECK_INIT,WWDG_Config);

void WWDG_Config(void)
{
  /* Enable WWDG clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);
  /* WWDG clock counter = (PCLK1 (48MHz)/4096)/8 = 1464Hz (~683 us)  */
  WWDG_SetPrescaler(WWDG_Prescaler_8);
  /* Set Window value to 80; WWDG counter should be refreshed only when the counter
    is below 80 (and greater than 64) otherwise a reset will be generated */
  WWDG_SetWindowValue(125);
  /* Enable WWDG and set counter value to 127, WWDG timeout = ~683 us * 64 = 43.7 ms 
     In this case the refresh window is: ~683 * (127-80)= 32.1ms < refresh window < ~683 * 64 = 43.7ms
     */
  WWDG_Enable(127);
  /* Stops the WWDG when the COrtexM0 Core is halted (i.e. when a breakpoint is set) */
}
void Feed_Dog()
{
			if((WWDG->CR&0x7f)<0x60&&(WWDG->CR&0x7f)>0x40)
			{
				///printf("WWDG->CR=%d\r\n",WWDG->CR&0x7f);
				WWDG_SetCounter(127);
			}
}
