/**
 * @file cpost.c
 * @author Letter (nevermindzzt@gmail.com)
 * @brief c post
 * @version 1.0.0
 * @date 2020-10-31
 * 
 * @copyright (c) 2020 Letter
 * 
 */
#include "main.h"


CpostHandler cposhHandlers[CPOST_MAX_HANDLER_SIZE] = {0};


/**
 * @brief cpost 添加handler
 * 
 * @param param 参数
 * 
 * @return signed char 0 成功 -1 失败
 */
signed char cpostAddHandler(CpostParam *param)
{
        switch (param->attrs.flag&0x03)
        {
        case CPOST_FLAG_CLEAR_FRONT:
           // cpostRemove(param->handler, param->attrs.paramDiff ? param->param : NULL);
            break;

        case CPOST_FLAG_CANCEL_CURRENT:
					 if (cpostIsInList(param->handler, param->attrs.paramDiff ? param->param : NULL) == 0)
						{
								cpostRemove(param->handler, param->attrs.paramDiff ? param->param : NULL);
						}
						return 0;
            
            // break;

        case CPOST_FLAG_ADD_NEW:
							if (cpostIsInList(param->handler, param->attrs.paramDiff ? param->param : NULL) == 0)
							{
								return 0;
							}
						break;

        default:
            break;
        }
                for (size_t i = 0; i < CPOST_MAX_HANDLER_SIZE; i++)
									{
											if (cposhHandlers[i].handler == NULL)
											{
													cposhHandlers[i].startTime = CPOST_GET_TICK();
													cposhHandlers[i].delay = param->delay;
													cposhHandlers[i].handler = (void (*)(void *))(param->handler);
													cposhHandlers[i].param = param->param;
													cposhHandlers[i].funcstate=param->attrs.flag&0x04;
													return 0;
											}
									}

    return -1;
}


/**
 * @brief 移除handler
 * 
 * @param handler handler
 * @param param 参数，传 `NULL` 表示不比较参数
 * 
 */
void cpostRemove(void *handler, void *param)
{
    for (size_t i = 0; i < CPOST_MAX_HANDLER_SIZE; i++)
    {
        if (cposhHandlers[i].handler == handler
            && (param == NULL || param == cposhHandlers[i].param))
        {
            cposhHandlers[i].handler = NULL;
        }
    }
}

/**
 * @brief 移除所有handler
 * 
 */
void cpostRemoveAll(void)
{
    for (size_t i = 0; i < CPOST_MAX_HANDLER_SIZE; i++)
    {
        cposhHandlers[i].handler = NULL;
    }
}


/**
 * @brief 判断handler是否已经在列表中
 * 
 * @param handler handler
 * @param param 参数，传 `NULL` 表示不比较参数
 * 
 * @return signed char 0 存在 -1 不存在
 */
signed char cpostIsInList(void *handler, void *param)
{
    for (size_t i = 0; i < CPOST_MAX_HANDLER_SIZE; i++)
    {
        if (cposhHandlers[i].handler == handler
            && (param == NULL || param == cposhHandlers[i].param))
        {
            return 0;
        }
    }
    return -1;
}
/**
 * @brief cpost 处理
 * 
 */
void cpostProcess(void)
{
    size_t tick;
    for (size_t i = 0; i < CPOST_MAX_HANDLER_SIZE; i++)
    {
        if (cposhHandlers[i].handler)
        {
            tick = CPOST_GET_TICK();
            if (cposhHandlers[i].delay == 0 || 
                (CPOST_MAX_TICK - cposhHandlers[i].startTime > cposhHandlers[i].delay
                    ? tick - cposhHandlers[i].startTime >= cposhHandlers[i].delay
                    : CPOST_MAX_TICK - cposhHandlers[i].startTime + tick >= cposhHandlers[i].delay))
            {
                cposhHandlers[i].handler(cposhHandlers[i].param);
								if(cposhHandlers[i].funcstate==CPOST_FLAG_CIRCULAR)				//如果函数的执行方式为默认方式(执行一次)，则清除当前函数
								{
									 cposhHandlers[i].startTime = CPOST_GET_TICK();		//重新计时
								}
								else
									 cposhHandlers[i].handler = NULL;
            }
        }
    }
}

