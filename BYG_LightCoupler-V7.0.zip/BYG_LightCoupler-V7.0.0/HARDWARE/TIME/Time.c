#include "Time.h"
#include "motor.h"
#include "stdio.h"
#include "gps.h"
#include "wave.h"
#include "cevent.h"
#include "myevent.h"
uint16_t ScanLoop_10ms=0;

uint32_t Tick_Timer=0;


CEVENT_EXPORT(EVENT_BEFORE_CHECK_INIT,Time2_init,(const void*)MORTOR_MAX_SPEED_LIMIT,(const void*)47);

CEVENT_EXPORT(EVENT_BEFORE_CHECK_INIT,Time3_config,(const void*)1000,(const void*)47);


void Time2_init(uint16_t per,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef	TIM_TimeBaseStructure;
	NVIC_InitTypeDef	NVIC_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	TIM_DeInit(TIM2);
	TIM_TimeBaseStructure.TIM_ClockDivision	=	TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode		=	TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period				=	per;
	TIM_TimeBaseStructure.TIM_Prescaler			=	psc;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseStructure);
	
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	NVIC_InitStructure.NVIC_IRQChannel	=	TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd	=	ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	=	0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority	=	0;
	NVIC_Init(&NVIC_InitStructure);
	TIM_Cmd(TIM2,ENABLE);
	
}
void	TIM2_IRQHandler()						//������е�ʵʱ��Ҫ��Ƚϸߣ����Բ����ò�ѯ���������
{
	  if(TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)//����Ƿ�Ϊ����ж�
    {
					TIM_ClearITPendingBit(TIM2, TIM_IT_Update);//����жϱ�־λ����������ʱ������жϷ�����
				if(motor.Cal_Pulse>0)					//�ж��ۼ����е���������Ƿ����Ŀ���������
				{
					//printf("123\r\n");
					 if(GPIO_ReadOutputDataBit(CLKPORT,CLKPIN)==SET)
					 {
						 GPIO_ResetBits(CLKPORT,CLKPIN);
					 }
					else
					 {	 
							GPIO_SetBits(CLKPORT,CLKPIN);
							TIM2->ARR=motor.Motor_Speed;
							motor.Cal_Pulse--;
							motor.Pulse_Inground++;
					 }
				}
						TIM_ClearITPendingBit(TIM2, TIM_IT_Update);//����жϱ�־λ����������ʱ������жϷ�����
		}		
}





void Time3_config(uint16_t per,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef	TIM_TimeBaseStructure;
	NVIC_InitTypeDef	NVIC_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	TIM_DeInit(TIM3);
	TIM_TimeBaseStructure.TIM_ClockDivision	=	TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode		=	TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period				=	per;
	TIM_TimeBaseStructure.TIM_Prescaler			=	psc;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);
	
	
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
	NVIC_InitStructure.NVIC_IRQChannel	=	TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd	=	ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	=	1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority	=	0;
	NVIC_Init(&NVIC_InitStructure);
	TIM_Cmd(TIM3,ENABLE);
}


void	TIM3_IRQHandler()
{
	if(TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)//����Ƿ�Ϊ����ж�
	{
		Tick_Timer++;	
		//printf("123\r\n");
		//RefreshAngle();
		//piLoop(motor.Target_Pulse);
//	ScanLoop_10ms++;
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);//����жϱ�־λ����������ʱ������жϷ�����
	}
}



//void ScanLoop(void(*fun)(void))
void ScanLoop()
{
	static uint8_t status_flag=0;
		motorLog();
		if(motor.Cal_Pulse>0)
		{
			status_flag=0xF0;
		}else 
		{
			status_flag++;
			if((status_flag&0x0f)>5)
			{
				if(status_flag&0xf0)
				{
					my_printf(3,"\r\nPTZ GOTO FINISH\r\n");
					boardConfig.tarAngle=motor.Current_Pulse;
					boardConfig.configStatus=CONFIG_COMMIT;	
				}
					status_flag=0;
			}
		}
}

uint32_t Get_Tick()
{
	return Tick_Timer;
}



