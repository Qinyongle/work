#ifndef _Dog_h_
#define _Dog_h_

void WWDG_Config(void);
void Feed_Dog(void);
#endif
