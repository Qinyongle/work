#include "gps.h"
#include "math.h"
#include "stdint.h"
#include "stdio.h"
#include "flash.h"
#include "delay.h"
#include "string.h"
#include "usart.h"
#include "cevent.h"
#include "cpost.h"
#include "myevent.h"
#include "interface.h"
double lng1=0,lat1=0,lng2=114.189141,lat2=22.570671;
double sCourse,tCourse,aCourse,zDegree,deltaDegree;
TIME_STRUCT myTime={0};
GPS_STATUS gps_status=init;
nmeaGPGGA myGPGGA;
nmeaHEADINGA myHEADINGA;
nmeaINFO   GPSinfo;
uint8_t Gps_testFlag=0;

double RadisToAngle(double radis)
{
	return radis * 180 / PI;
}

double AngleToRadis(double angle)
{
	return angle / 180 * PI;
}

void Sum(uint8_t *p) 
{
	*(p+6)	=	(*(p+1)+*(p+2)+*(p+3)+*(p+4)+*(p+5))&0xff;
}

double get_angle(double AW, double Aj, double BW, double Bj)
{
	double a;
	double cos_c,sin_c;
	AW = AngleToRadis(AW);
	Aj = AngleToRadis(Aj);
	BW = AngleToRadis(BW);
	Bj = AngleToRadis(Bj);
	cos_c = sin(BW)*sin(AW) + cos(BW)*cos(AW)*cos(Bj - Aj);
	sin_c = sqrt(1- cos_c* cos_c);
	a = asin((cos(BW)*sin(Bj - Aj) / sin_c));
	a = RadisToAngle(a);
	if ((BW > AW) && (Bj > Aj))
	{
		return a;
	}
	else if ((BW > AW) && (Bj < Aj))
	{
		return 360+a;
	}
	else if ((BW < AW) && (Bj < Aj))
	{
		return 180 - a;
	}
	else if ((BW < AW) && (Bj > Aj))
	{
		return 180 - a;
	}
	else
		return 0;
}

static TIME_STRUCT UTC2CST(double value)
{
	TIME_STRUCT time;
	int8_t Hours,Minute,Second;
	 
	uint8_t CHours;
	Hours=value/10000.0;
	Minute=(value-(Hours*10000))/100.0;
	Second=(int)value%100;
	Second=Second;

	CHours=Hours+8;
	if(CHours>=24)CHours=CHours-24;
	time.Hours=CHours;
	time.Minute=Minute;

	time.Seconds=Second;
	return time;
	//if(Hours>=16&&Hours<)Hours=
}

static void gpsTransform(double *lng,double *lat)
{
	double degree,minute;
	degree=(int)*lng/100;
	minute=*lng-degree*100;
	*lng=degree+minute/60.0;
	//printf("de=%lf,mi=%lf,sec=%lf,lng=%lf\r\n",degree,minute,second,*lng);

	degree=(int)*lat/100;
	minute=*lat-degree*100;
	*lat=degree+minute/60.0;
	//printf("de=%lf,mi=%lf,sec=%lf,lng=%lf\r\n",degree,minute,second,*lat);
}

static void nmea_GPGGA2info(nmeaGPGGA *pack,nmeaHEADINGA *pack1 , nmeaINFO *info)
{

	
    info->sig = pack->sig;
    info->HDOP = pack->HDOP;
    info->elv = pack->elv;
    info->lat = ((pack->ns == 'N')?pack->lat:-(pack->lat));
    info->lon = ((pack->ew == 'E')?pack->lon:-(pack->lon));
		info->satinfo.inuse=pack->satinuse;
		info->elv=pack->elv;
		info->headingA=pack1->headingA;
}



void nmea_GpsInfo_Printf(nmeaINFO *gps_data)
{
		printf("===========================================================\n");
		printf("==   ʱ�� : %d-%d-%d\n",						myTime.Hours,myTime.Minute,myTime.Seconds);
    printf("==   γ�� : ��γ:%lf                         \n",gps_data->lat);
    printf("==   ���� : ����:%lf                              \n", gps_data->lon);
    printf("==   ����� : %.3f                                       \n",gps_data->headingA);
		printf("==   ����Ƿ��� : %.3f                                       \n",gps_data->headingA_var);
		printf("==   ������ : %.3f                                       \n",gps_data->pitch);
		printf("==   ˮƽ�������� �� %.3f                                 \n",gps_data->HDOP);
		printf("==   ����״̬ �� %d                                 \n",gps_data->sig);
		printf("==   ������������ �� %d                                 \n",gps_data->satinfo.inuse);
    printf("============================================================\n");
		
}
float Cal_Angle(float angle)
{
	static float lastAngle=0;
	static float trueAngle=0;
	static uint8_t TruedataCount=0;
	static uint8_t SubdataCount=0;
	if(trueAngle==0)trueAngle=53;
	if(Gps_testFlag==1)
	{
		my_printf(3,"trueAngle=%lf,lastAngle=%lf,TruedataCount=%d,angle=%lf\r\n",trueAngle,lastAngle,TruedataCount,angle);
	}
	if((fabs(angle-trueAngle)>=180?(360.0-fabs(angle-trueAngle)):(fabs(angle-trueAngle)))>3.0)
	{
			TruedataCount++;
    if((fabs(angle-lastAngle)>=180?(360.0-fabs(angle-lastAngle)):(fabs(angle-lastAngle)))>3.0)
		{
			TruedataCount=0;
		}
		lastAngle=angle;
		if(TruedataCount>=20)
		{
			trueAngle=angle;
			TruedataCount=0;
			return angle;
		}
		return trueAngle;
	}
	else
	{
		TruedataCount=0;
		trueAngle=angle;
		return angle;
	}
}
uint8_t Getgps(uint8_t *p,uint8_t sta)
{
		int a=0;
		char	*adr;
		static double tempScourse=0,templat=0,templng=0;
		double time;

		a+=sscanf((const char*)p,"$GPGGA,%lf,%lf,%c,%lf,%c,%d,%d,%lf,%lf,%c,%lf,%c,%lf,%d",&time,&templat,&myGPGGA.ns,&templng,&myGPGGA.ew,&myGPGGA.sig,\
															&myGPGGA.satinuse,&myGPGGA.HDOP,&myGPGGA.elv,&myGPGGA.elv_units,&myGPGGA.diff,&myGPGGA.diff_units,\
															&myGPGGA.dgps_age,&myGPGGA.dgps_sid);
	//	adr=strstr((const char*)p,"SOL_COMPUTED");
	
		adr=strstr((const char*)p,";");
		a+=sscanf(adr,";%[^,],%[^,],%lf,%lf,,%lf,%*[^,],%lf",myHEADINGA.cal_state,myHEADINGA.pos_type,&myHEADINGA.baseline,&myHEADINGA.headingA,\
							&myHEADINGA.pitch,&myHEADINGA.headingA_var);						//%*[A-Z]����NARROW_INT,%*[0-9]������һ������
		
		myTime =  UTC2CST(time);
	
//		sCourse=Cal_Angle(myHEADINGA.headingA);
		if((myHEADINGA.headingA<=360&&myHEADINGA.headingA>=0))					//����gps������ʱ��ͻȻ����ƫ�������ת�����ԽǶ�˲ʱ�仯45�����ϵ����ݲ�����
		{
			if(fabs(myHEADINGA.headingA-sCourse)>=180)
			{
				if(((360.0f-fabs(myHEADINGA.headingA-sCourse))<45.0f)||sCourse==0)sCourse=myHEADINGA.headingA;
			}
			else
			{
				sCourse=myHEADINGA.headingA;
			}
		}
		gpsTransform(&templng,&templat);
		if((fabs(templat-myGPGGA.lat)<0.01f)||(myGPGGA.lat==0))myGPGGA.lat=templat;
		if((fabs(templng-myGPGGA.lon)<0.01f)||(myGPGGA.lon==0))myGPGGA.lon=templng;
		nmea_GPGGA2info(&myGPGGA,&myHEADINGA ,&GPSinfo);
		my_printf(3,"Cordinate%lf,N,%lf,E,%lf\r\n",myGPGGA.lat,myGPGGA.lon,sCourse);
		return 1;
//		if(a==4)
//			return 1;
//		else 
//			return 0;
}




uint8_t SetOppositeGps(uint8_t *p)
{
	int a;
	a=sscanf((const char*)p,"SET,N,%lf,E,%lf",&lat2,&lng2);
	if(a==2)
	{
		return 1;
	}
	else
		return 0;
}

void ReadGps()
{
//	printf("ln1=%lf,la1=%lf,ln2=%lf,la2=%lf\r\n",lng1,lat1,lng2,lat2);
	my_printf(3,"ln1=%lf,la1=%lf,ln2=%lf,la2=%lf\r\n",lng1,lat1,lng2,lat2);
}



uint8_t  isConnected()
{	
	static uint8_t times=0;
	if(USART_RX_STA&0x10000)
	{
	  if(strstr((char*)USART_RX_BUF, "$GPGGA") != NULL&&strstr((char*)USART_RX_BUF, "#HEADINGA") != NULL)
		{
			times++;
		}
		if(times>10)
		{
			times=0;
			return 1;
		}
		USART_RX_STA=0;
		memset(USART_RX_BUF,0,strlen((const char*)USART_RX_BUF));	
	}
		return 0;
}

uint8_t Check_Gps()
{
	static uint8_t flag=0;
	if(isConnected()!=1)
	{
		USARTN=USART1;
		if(flag==0)
		{
			flag=1;
			my_printf(1,"LOG COM3 GPGGA ONTIME 0.3\r\n");
		}
		else
		{
			flag=0;
			my_printf(1,"LOG COM3 HEADINGA ONTIME 0.3\r\n");
		}
		return 0;
	}
	gps_status=init_success;
	return 1;
}
	
void nmea_zero_GPGGA(nmeaGPGGA *pack)
{
    memset(pack, 0, sizeof(nmeaGPGGA));
    pack->ns = 'N';
    pack->ew = 'E';
    pack->elv_units = 'M';
    pack->diff_units = 'M';
		pack->lat=0;
		pack->lon=0;
}


void GPS_init()
{
	if(gps_status==init)
	{
		cpost(Check_Gps, .attrs.flag=CPOST_FLAG_CIRCULAR,.delay=1000);	
		nmea_zero_GPGGA(&myGPGGA);
		my_printf(3,"init\r\n");
		gps_status=init_failed;
	}
	else 	if(gps_status==init_success)
	{
		cpost(Check_Gps, .attrs.flag=CPOST_FLAG_CANCEL_CURRENT);  //ж��У�麯��
		cpost(Usart_Process,.attrs.flag=CPOST_FLAG_CIRCULAR,.delay=100);
		gps_status=init_failed;
		my_printf(3,"init_success\r\n");
	}
	else if(gps_status==init_failed)
	{
		;
	}
}




