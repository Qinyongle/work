#ifndef _opto_h
#define _opto_h
#include "sys.h"
#include "stm32f10x.h"


#define opto_pin		GPIO_Pin_9|GPIO_Pin_8|GPIO_Pin_7|GPIO_Pin_6
#define opto_Port		GPIOC
 union P{
	uint8_t PINx;
	struct {
	unsigned char bit0:1;
	unsigned char bit1:1;
	unsigned char bit2:1;
	unsigned char bit3:1;
	unsigned char bit4:1;
	unsigned char bit5:1;
	unsigned char bit6:1;
	unsigned char bit7:1;
}Bits;
};
extern union P optp_Bits;
#define opto0 PCin(9) 
#define opto1 PCin(8) 
#define opto2 PCin(7) 
#define opto3 PCin(6) 

enum Num_xx{
	Num_0=0,
	Num_90=400,
	Num_180=800,
	Num_270=1200,
	Num_360=1600,
};
 

uint8_t Read_Bit(void);
void GPIO_opto_init(void);
void Deal(void);

#endif

