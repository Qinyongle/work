#include "interface.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
uint8_t temp_buffer[TEMP_SIZE]={0};
uint8_t lora_address[]={0xff,0xff,0x0c};

double longitude=0,latitude=0;
uint8_t lat_status=0,long_status=0;
float azimuth_Angle=0;


uint8_t header_Frame[]="Cordinate";

uint8_t data_Frame[100]={0};

uint8_t isConnected()
{
	static uint8_t times=0;
	if(rx_end_flag==1)
	{
		
		if(strstr((const char*)rx_buff,"$GPGGA")!=NULL&&strstr((const char*)rx_buff,"#HEADINGA")!=NULL)
		{
			times++;
		}
		rx_end_flag=0;
		memset(rx_buff,0,strlen((const char*)rx_buff));	
	}
	if(times>10)
	{
		return 1;
	}
	else return 0;
}
void send_ToLora(uint8_t *str)
{
		huartx=huart2;
		printf("%s",lora_address);   
		printf("%s\r\n",str);
}
void Usart_Process()
{
	char* p;
	char temp[5];
	//p=(char*)malloc(sizeof(char*));
	int i=0;
//	huartx=huart2;
//	printf("this is from usart2\r\n");
//	HAL_Delay(10);
//	huartx=huart3;
//	printf("this is from usart3\r\n");
	
	
//		HAL_Delay(100);
//		send_ToLora("100214");
//	HAL_Delay(10);
//	huartx=huart5;
//	printf("this is from usart5\r\n");
//	HAL_Delay(10);
	
	if(rx_end_flag==1)
	{
		rx_end_flag=0;
		sscanf((const char*)rx_buff,"$GPGGA,%*[^,],%lf,N,%lf,E",&latitude,&longitude);
	
		p=strstr((const char*)rx_buff,"SOL_COMPUTED");							//��ȡ��NARROW_INT������ַ���
		sscanf(p,"%*[^,],%*[^,],%*[^,],%f",&azimuth_Angle);						//%*[A-Z]����NARROW_INT,%*[0-9]������һ������

		huartx=huart2;
		for(int i=0;i<3;i++)
		{
				printf("%c",lora_address[i]);   
		}
		printf("Cordinate%lf,N,%lf,E,%lf\r\n",latitude,longitude,azimuth_Angle);
		Rx_count=0;
		memset(rx_buff,0,strlen((const char*)rx_buff));
	}


}void onusart()
{
	;
}