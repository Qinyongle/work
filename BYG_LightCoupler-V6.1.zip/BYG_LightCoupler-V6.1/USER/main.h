#ifndef _main_h_
#define _main_h_
#include "stm32f10x_gpio.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "usart.h"
#include "motor.h" 
#include "Dog.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"
#include "flash.h"
#include "interface.h"
#include "Time.h"
#include "gps.h"


#define BOARD "3.0"
#define VERSION "6.1.0��change from 5.1.0)"
#define TIME "2022.10.24"
enum BORDMOdE
{
	CheckMode,
	UsartMode,
	BugMode,
};
extern enum BORDMOdE BordMode;
#endif