#ifndef _wave_h_
#define _wave_h_

#include "usart.h"




void sent_data(int32_t A,int32_t B,int8_t C);

#endif