#ifndef _limit_switch_h_
#define _limit_switch_h_
#include <stdint.h>
#include "stm32f10x_gpio.h"

#define LIMIT_PORT GPIOB
#define LIMIT_PIN0 GPIO_Pin_0
#define LIMIT_PIN1 GPIO_Pin_12
typedef enum
{
	ON=1,
	OFF,
}STATUS;
typedef struct
{
	GPIO_TypeDef* GPIOx;
	uint16_t GPIO_Pin_x;
}LS;


extern LS LS_RIGHT,LS_LEFT;		
STATUS LS_STATUS_READ(LS *p);
void Limit_Switch_Init(void);
#endif
