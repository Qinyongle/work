#include "motor.h" 
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include <math.h>
#include "delay.h"
#include "exti.h"
#include "sys.h" 
#include <string.h>
#include "usart.h"
#include "light_Coupler.h"
#include "interface.h"
#include "gps.h"
#include "flash.h"

uint16_t Motor_Fre=40;

int32_t incrementAngle=0;			//�����Ƕ�
double compensateAngle=0;

PID_t location={0};
MOTOR motor={0};				//ʵ��һ�����

u16 Flag_Update=0,Flag_Update_App=0;



void motorLog()
{
	if(Log)													//�Ƿ��ӡ��־
	{
		printf("motor.Cal_Pulse=%d,,motor.Pulse_Inground=%d,Tar_angle=%d,est_Pulse=%d\r\n",motor.Cal_Pulse,motor.Pulse_Inground,motor.Target_Pulse,motor.est_Pulse);
  	printf("1currentAngle=%lf,offsetAngle=%lf,motor.Current_Position=%lf,motor.motor.Direction=%d\n",motor.Current_Pulse*STEP_ANGLE,motor.Pulse_Inground*STEP_ANGLE,motor.Current_Position*STEP_ANGLE,motor.Direction);
	}
}
void writeCompensation(double Comp)
{
	int16_t temp;
	temp=Comp*10;
	Flash_wirte(4,(uint8_t*)&temp,1);
}
void readCompensation(double *Comp)
{
	int16_t temp;
	temp=(int16_t)Flash_Read(4);
	if(temp==-1)temp=0;
	*Comp=(double)(temp)/10.0;
}
void motor_GpioInit()
{

	GPIO_InitTypeDef  GPIO_InitStructure;
		GPIO_DeInit(GPIOA);
	GPIO_DeInit(GPIOB);
	GPIO_DeInit(GPIOC);
	GPIO_DeInit(GPIOD);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//ʹ��PORTA,PORTEʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);//ʹ��PORTA,PORTEʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTA,PORTEʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	
	 GPIO_InitStructure.GPIO_Pin = CLKPIN;								 
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	 GPIO_Init(CLKPORT, &GPIO_InitStructure);			

	 GPIO_InitStructure.GPIO_Pin = DIRECTIONPIN;								 
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	 GPIO_Init(DIRECTIONPORT, &GPIO_InitStructure);		
	
	 GPIO_InitStructure.GPIO_Pin = ENABLEPIN;								 
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	 GPIO_Init(ENABLEPORT, &GPIO_InitStructure);	
	
}
 
 double CompensateAngle(double angle)
{
	if(compensateAngle>limitCompensate)							//�������޶���Χ
	{
		compensateAngle=limitCompensate;
	}
	else if(compensateAngle<-limitCompensate)
	{
		compensateAngle=-limitCompensate;
	}
	angle+=compensateAngle;					//���򲹳���Ϊ���������򲹳���Ϊ����
	if(angle>360.0)
	{
		return (angle -360);
	}
	else if(angle<0)
	{
		return angle+360;
	}
	return angle;
}



void getAntAngle()					//��ȡ�����������ļн�
{
	if(zDegree>=0&&zDegree<=180)
	{
		if(sCourse>=0&&sCourse<=180)
		{
			aCourse=zDegree+sCourse;
		}
		else
		{
			aCourse=zDegree-(360-sCourse);
		}
	}
	else if(zDegree>180.0&&zDegree<=360.0)
	{
		if(sCourse>180.0&&sCourse<=360.0)
		{
			aCourse=(zDegree+sCourse)-360.0;
		}
		else
		{
			aCourse=sCourse-(360-zDegree);
		}
	}
}
/*���߸���*/
void antTracker()
{
	double deltaAngle=0;
	static double lastTarget=0;
	static char flag_status=1;
	
	if(lat1==0||lat2==0||lng1==0||lng2==0)
	{
		return;
	}
	tCourse=get_angle(lat1,lng1,lat2,lng2);				//��ȡ�����㺽���
	
	zDegree=motor.Current_Pulse*STEP_ANGLE;					//��ȡ�����ڿ̶����ϵĽǶ�
	
	getAntAngle();																//�������ߺ����
	
	deltaAngle=aCourse-zDegree;										//�������ߵĺ����������ƫ�ƽǶȵ����
	if(deltaAngle>180)
	{
		deltaAngle -=360;
	}
	else if(deltaAngle<-180)
	{
		deltaAngle +=360;
	}

	deltaDegree=tCourse-deltaAngle;								//����Ŀ��Ƕ�
	if(deltaDegree<0)
	{
		deltaDegree+=360.0;
	}
	else if(deltaDegree>360)
	{
		deltaDegree=360-deltaDegree;
	}
	
	deltaDegree=CompensateAngle(deltaDegree);			//�����Ƕ�
	if(fabs(lastTarget-deltaDegree)<0.7)					//Ŀ��Ƕȱ仯0.7�����²�����
	{
		return;
	}
	lastTarget=deltaDegree;
	printf("tarAngle=%lf\r\n",deltaDegree);
	
	if(deltaDegree<=360.0&&deltaDegree>=0)
	motor.Target_Pulse=deltaDegree/STEP_ANGLE;				//��ֵĿ��Ƕ�

}

/*��������*/
void RefreshAngle()
{
	if(motor.Direction==1)
	{
		//measure
		motor.Current_Position=motor.Current_Position+motor.Pulse_Inground;
		if(motor.Current_Position>OneCircleNums)motor.Current_Position=motor.Current_Position-OneCircleNums;
		
		//estimate
		motor.est_Pulse=motor.est_Pulse+motor.Pulse_Inground;
		if(motor.est_Pulse>OneCircleNums)motor.est_Pulse=motor.est_Pulse-OneCircleNums;
		
		
		motor.Pulse_Inground=0;

	}
	else if(motor.Direction==-1)
	{
		
		//measure
		if(motor.Current_Position==0)motor.Current_Position=OneCircleNums;
		
		if((motor.Current_Position<motor.Pulse_Inground))
					motor.Current_Position=OneCircleNums-(motor.Pulse_Inground-motor.Current_Position);
		else  
					motor.Current_Position=motor.Current_Position-motor.Pulse_Inground;
		
		
		//estimate
				if(motor.est_Pulse==0)motor.est_Pulse=OneCircleNums;
		
		if((motor.est_Pulse<motor.Pulse_Inground))
					motor.est_Pulse=OneCircleNums-(motor.Pulse_Inground-motor.est_Pulse);
		else  
					motor.est_Pulse=motor.est_Pulse-motor.Pulse_Inground;
		
					motor.Pulse_Inground=0;
	}
			motor.Current_Pulse=motor.Current_Position;
//		motor.Current_Pulse=motor.Current_Position-(compensateAngle/STEP_ANGLE);
//	if(motor.Current_Pulse>=OneCircleNums)motor.Current_Pulse=motor.Current_Pulse-OneCircleNums;

}

void pid_Init()
{
	location.kp=1;
	location.ki=0;
	location.kd=0;
}
void piLoop(uint32_t TarAngle)
{
			int32_t deltaAngle;
//		TarAngle=	CompensateAngle(TarAngle*STEP_ANGLE)/STEP_ANGLE;
		 deltaAngle=TarAngle-motor.Current_Pulse;
	if(deltaAngle > OneCircleNums >> 1)
			incrementAngle = deltaAngle-OneCircleNums;
	else if (deltaAngle < -OneCircleNums >> 1)
			incrementAngle = deltaAngle+OneCircleNums;
	else
			incrementAngle=deltaAngle;
	
	
			location.ErrorLast=location.Error;
			location.Error=incrementAngle;
			if(abs(location.Error)<=(uint32_t)DEADSPACE)
			{
			location.Error=0;
			}
			location.outputKp=location.kp*(location.Error);
			location.outputKi+=location.ki*location.Error;
			location.outputKd=location.kd*(location.Error-location.ErrorLast);
			
			if(location.outputKi>OneCircleNums>>2)
			{
				location.outputKi=OneCircleNums>>2;
			}
			location.output=location.outputKp+location.outputKi+location.outputKd;
	
	
			if(location.output>0)
			{
				SET_LEFT;	
				motor.Direction=1;
			}
			else if(location.output<0)
			{
				SET_RIGHT;
				motor.Direction=-1;
			} 
			motor.Cal_Pulse=abs(location.output);
			
			pid_Speed(abs(location.output),motor.Motor_Speed);
//		if(abs(incrementAngle)<=(uint32_t)DEADSPACE)
//			{
//				incrementAngle=0;
//			}
//			if(incrementAngle>0)
//			{
//				SET_LEFT;	
//				motor.Direction=1;
//			}
//			else if(incrementAngle<0)
//			{
//				SET_RIGHT;
//				motor.Direction=-1;
//			} 

//			motor.Cal_Pulse=kp*abs(incrementAngle);
//			incrementAngle=0;
}
void pid_Speed(int32_t Input,int32_t actualSpeed)
{
		if(Input>Aceel_Num)				//���ڼ��ٲ�����ʼ����
		{
			Input=256;			
		}
		else if(Input<3*Aceel_Num)						//С�ڼ��ٲ�����ʼ����
		{
			Input=0;
		}
		Input=-0.75f*(float)(Input)+256;			//�����ٶ�	
		motor.Goal_Speed=Input;
		Cal_Speed(motor.Goal_Speed);
}

void Cal_Speed(int16_t goal)
{
	int16_t delta_Speed;
	delta_Speed=goal-motor.Motor_Speed;
	if(delta_Speed>0)
		motor.Motor_Speed+=abs(delta_Speed/4)>1?(abs(delta_Speed/4)):1;
	else if(delta_Speed<0)
		motor.Motor_Speed-=abs(delta_Speed/4)>1?(abs(delta_Speed/4)):1;
	//printf("\r\nMotor_Fre=%d,goal=%d,delta_Speed=%d\r\n",motor.Motor_Speed,goal,delta_Speed);
}

void check_Origin()
{
	SET_LEFT;								//���÷���
	motor.Direction=1;
	motor.Cal_Pulse=2*OneCircleNums;//�趨һȦ����
	TIM_Cmd(TIM2,ENABLE);		//��������
	delay_ms(500);
	while(1)
	{
		//printf("lc0=%d,lc1=%d\r\n",lc_buffer_positive[0]->GetStatus(lc_buffer_positive[0]),lc_buffer_positive[8]->GetStatus(lc_buffer_positive[8]));
		if((lc_buffer_positive[0]->GetStatus(lc_buffer_positive[0])==SET)&&(lc_buffer_positive[8]->GetStatus(lc_buffer_positive[8])==SET))
		{
			//delay_ms(5);
			if((lc_buffer_positive[0]->GetStatus(lc_buffer_positive[0])==SET)&&(lc_buffer_positive[8]->GetStatus(lc_buffer_positive[8])==SET))
			{
				break;
			}
		}
			Usart2_Process();
	}			//����Ƿ�ԭ��
	motor.Pulse_Inground = 0;		//���ۼ�����
	motor.Cal_Pulse=0;
	motor.Current_Pulse=0;				//��ʼ����ǰ�Ƕ�
	motor.Motor_Speed=MORTOR_MIN_SPEED_LIMIT;
	Scale=0;
}


/***@brief ��������Ӽ������� 
*		@param Fre[] ���ڴ�ÿ��������Ӧ��Ƶ�� 
*		@param len ���ٵĲ�����������һ��Ĳ������ڼ��٣�һ��Ĳ������ڼ��٣�Ҳ������ʼ���ٹ̶�����֮�����٣�Ȼ���ڿ�Ҫ����ǰ��ʼ�������٣�
*		@param FStart �������ʼ�ٶ� 
*		@param FStop �����Ŀ���ٶ� 
*		@param flexible ���ߵ�б�ʣ�Ҳ���Ǽ��ٵĿ�����ֵԽС����Խ����Խ�����Խ�죨һ�㽨����4-6֮�䣩
*	  @return Status
 ****/

void motorPower_PowerSLine(uint16_t Fre[], int len, int FStart, int FStop, int flexible)
{ 
		float deno; float melo; float num; float Fcurrent; int index = 0;
		for (index = 0; index < len; index++) { num = len / 2; 
		melo = flexible * (index - num) / num; 
		deno = 1.0 / (1 + exp(-melo));
		Fcurrent = FStart - ((FStart - FStop) * deno); 
		Fre[index] = (unsigned int)Fcurrent; }
}
