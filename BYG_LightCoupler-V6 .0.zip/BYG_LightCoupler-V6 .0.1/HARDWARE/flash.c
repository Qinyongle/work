#include "motor.h" 
#include "flash.h"
#include "delay.h"
#include "string.h"
uint8_t flash_Buffer[100]={0};
BoardConfig_t boardConfig;


void init()
{
	memset(flash_Buffer,0,100);
	memcpy(flash_Buffer, (uint8_t*) (start_sddress), 100);
}

uint16_t Flash_Read(uint32_t address)
{
	return *(__IO uint16_t*)(address);
}


uint32_t Flash_ReadWord(uint32_t address)
{
	uint32_t temp1,temp2;
	temp1=	*(__IO uint16_t*)(address);
	temp2=	*(__IO uint16_t*)(address+2);
	return (temp2<<16)+temp1;
}


uint8_t flash_Buffer_Read_Byte(uint16_t offset)
{
	return flash_Buffer[offset];
}

void flash_Buffer_Write_Byte(uint16_t offset,uint8_t data)
{
	 flash_Buffer[offset]=data;
}

void Flash_flush(uint32_t ADDR,uint32_t *buff,uint32_t num)
{
	uint8_t status;
	uint32_t i;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	if(FLASH_ErasePage(ADDR)==FLASH_COMPLETE)
	{
		for(i=0;i<num;i++)
		{
			 status=FLASH_ProgramWord(ADDR,buff[i]);
				ADDR += 4;
		}
				delay_ms(1);
	}
	FLASH_Lock();
}

void Flash_get(int _offset, BoardConfig_t *boardConfig)
{
		uint16_t offset = _offset;
		uint16_t count;
		uint8_t* _pointer = (uint8_t*) boardConfig;

		for ( count = sizeof(BoardConfig_t); count>0; --count, ++offset)
		{
				*_pointer++ = flash_Buffer_Read_Byte(offset);
		}
}



void Flash_put(int idx, BoardConfig_t boardConfig)
{
        uint16_t offset = idx;
				uint16_t count;
        const uint8_t* _pointer = (const uint8_t*) &boardConfig;

        for ( count = sizeof(boardConfig); count; --count, ++offset)
        {
            flash_Buffer_Write_Byte(offset, *_pointer++);
        }
            // Save the data from the buffer to the flash right away
          Flash_flush(start_sddress,(uint32_t *)flash_Buffer,sizeof(flash_Buffer)/sizeof(uint32_t));
}




void Flash_wirte(uint32_t ADDR,uint8_t *buff,uint8_t Word_flag)
{
	uint8_t status;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	if(FLASH_ErasePage(ADDR)==FLASH_COMPLETE)
	{
		if(Word_flag==Word)
		{
			 status=FLASH_ProgramWord(ADDR,buff[3]<<24|buff[2]<<16|buff[1]<<8|buff[0]);
		}
		else if(Word_flag==Half_Word)
				FLASH_ProgramHalfWord(ADDR,	(uint16_t)buff[0]|buff[1]<<8);
		
				delay_ms(1);
	}
	FLASH_Lock();
}


void Config()
{
	init();
	Flash_get(0,&boardConfig);
//	printf("boardConfig.Addrh=%c\r\n",boardConfig.Addrh);
//	printf("boardConfig.Addrl=%c\r\n",boardConfig.Addrl);
//	printf("boardConfig.Ch=%c\r\n",boardConfig.Ch);
	if(boardConfig.configStatus != CONFIG_OK)
	{
			boardConfig.configStatus = CONFIG_OK;
			boardConfig.GpsFlag=0;
			boardConfig.latitude=0;
		
			boardConfig.longitude=0;
		
			boardConfig.Speed=64;
			boardConfig.tarAngle=0;
			boardConfig.Compensation=0;
			Flash_put(0,boardConfig);
	}
}

void Set_Protection()
{	
	if(FLASH_GetReadOutProtectionStatus() != SET)
	{
		FLASH_Unlock();
		FLASH_ReadOutProtection(ENABLE);
		FLASH_Lock();
	}
}
void Reset_Protection()
{
	if(FLASH_GetReadOutProtectionStatus() != RESET)
	{
		FLASH_Unlock();
		FLASH_ReadOutProtection(DISABLE);
		FLASH_Lock();
	}
}
