#ifndef _Time_h_
#define _Time_h_
#include "stm32f10x.h"
#include <stdio.h>
#include "stdlib.h"
void Time2_init(uint16_t per,uint16_t psc);
void Time3_config(uint16_t per,uint16_t psc);
void ScanLoop(void);
extern uint8_t ScanLoop_10ms;
#endif




