#ifndef _light_Coupler_h_
#define _light_Coupler_h_
#include "stm32f10x.h"
#include "stdlib.h"


//#define lc0_Port GPIOC
//#define lc0_Pin  GPIO_Pin_10

//#define lc1_Port GPIOC
//#define lc1_Pin  GPIO_Pin_11

//#define lc2_Port GPIOB
//#define lc2_Pin  GPIO_Pin_12

//#define lc3_Port GPIOB
//#define lc3_Pin  GPIO_Pin_0

//#define lc4_Port GPIOC
//#define lc4_Pin  GPIO_Pin_9

//#define lc5_Port GPIOC
//#define lc5_Pin  GPIO_Pin_8

//#define lc6_Port GPIOC
//#define lc6_Pin  GPIO_Pin_7

//#define lc7_Port GPIOC
//#define lc7_Pin  GPIO_Pin_6


//#define Check_Port GPIOA
//#define Check_Pin  GPIO_Pin_3


///*���Բ�Ʒ�Ľ�λ*/

//#define lc0_Port GPIOC
//#define lc0_Pin  GPIO_Pin_8

//#define lc1_Port GPIOC
//#define lc1_Pin  GPIO_Pin_7

//#define lc2_Port GPIOC
//#define lc2_Pin  GPIO_Pin_6

//#define lc3_Port GPIOB
//#define lc3_Pin  GPIO_Pin_12

//#define lc4_Port GPIOB
//#define lc4_Pin  GPIO_Pin_0

//#define lc5_Port GPIOC
//#define lc5_Pin  GPIO_Pin_10

//#define lc6_Port GPIOC
//#define lc6_Pin  GPIO_Pin_11

//#define lc7_Port GPIOA
//#define lc7_Pin  GPIO_Pin_6


//#define Check_Port GPIOC
//#define Check_Pin  GPIO_Pin_9



/*�����Ĳ�Ʒ��λ*/

#define lc0_Port GPIOC
#define lc0_Pin  GPIO_Pin_8

#define lc1_Port GPIOC
#define lc1_Pin  GPIO_Pin_7

#define lc2_Port GPIOC
#define lc2_Pin  GPIO_Pin_6

#define lc3_Port GPIOA
#define lc3_Pin  GPIO_Pin_6

#define lc4_Port GPIOB
#define lc4_Pin  GPIO_Pin_12

#define lc5_Port GPIOB
#define lc5_Pin  GPIO_Pin_0

#define lc6_Port GPIOC
#define lc6_Pin  GPIO_Pin_10

#define lc7_Port GPIOC
#define lc7_Pin  GPIO_Pin_11


#define Check_Port GPIOC
#define Check_Pin  GPIO_Pin_9

#define OriginPin 	0

#define lc_Num 			9					//�������
#define nPointer		9					//ָ�����

#define cycle       360.0/(float)nPointer		//ָ��У�������
#define gapAngle 		(360.0/((float)(lc_Num-1)*(float)nPointer))
#define gapLcAngle	360.0/(lc_Num-1)

enum
{
	ON,
	OFF,
	INVALID,
};

enum
{
	lc0=0,
	lc1,
	lc2,
	lc3,
	lc4,
	lc5,
	lc6,
	lc7,
	lc8,
	invalid,
};

struct LIGHTCOUPLER
{
	uint8_t Serial_Number;
	GPIO_TypeDef *Port;
	uint32_t Pin;
	
	uint8_t (*GetSerialNum)(struct LIGHTCOUPLER *lighCoup);
	uint8_t (*GetStatus)(struct LIGHTCOUPLER *lighCoup);
};

extern struct LIGHTCOUPLER *lc_buffer_positive[];
extern int8_t Scale;
extern uint8_t Refresh,period,BUG;	
void light_Coupler_Init(void);
void scanLighCoup(void);
int32_t getAngle(void);
void RefreshCurPositon(int32_t * position);
void angleRef(int32_t *value);
#endif
