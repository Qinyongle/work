#include "gps.h"
#include "math.h"
#include "stdint.h"
#include "stdio.h"
#include "flash.h"
#include "delay.h"
#include "string.h"
#include "usart.h"
double lng1=0,lat1=0,lng2=114.189141,lat2=22.570671;
double sCourse,tCourse,aCourse,zDegree,deltaDegree;
double RadisToAngle(double radis)
{
	return radis * 180 / PI;
}

double AngleToRadis(double angle)
{
	return angle / 180 * PI;
}
void Sum(uint8_t *p) 
{
	*(p+6)	=	(*(p+1)+*(p+2)+*(p+3)+*(p+4)+*(p+5))&0xff;
}
double get_angle(double AW, double Aj, double BW, double Bj)
{
	double a;
	double cos_c,sin_c;
	double distance;
	AW = AngleToRadis(AW);
	Aj = AngleToRadis(Aj);
	BW = AngleToRadis(BW);
	Bj = AngleToRadis(Bj);
	cos_c = sin(BW)*sin(AW) + cos(BW)*cos(AW)*cos(Bj - Aj);
	sin_c = sqrt(1- cos_c* cos_c);
	a = asin((cos(BW)*sin(Bj - Aj) / sin_c));
	a = RadisToAngle(a);
	if ((BW > AW) && (Bj > Aj))
	{
		return a;
	}
	else if ((BW > AW) && (Bj < Aj))
	{
		return 360+a;
	}
	else if ((BW < AW) && (Bj < Aj))
	{
		return 180 - a;
	}
	else if ((BW < AW) && (Bj > Aj))
	{
		return 180 - a;
	}
	else
		return 0;
}


static void gpsTransform(double *lng,double *lat)
{
	double degree,minute,second;
	degree=(int)*lng/100;
	minute=*lng-degree*100;
	*lng=degree+minute/60.0;
	//printf("de=%lf,mi=%lf,sec=%lf,lng=%lf\r\n",degree,minute,second,*lng);

	degree=(int)*lat/100;
	minute=*lat-degree*100;
	*lat=degree+minute/60.0;
	//printf("de=%lf,mi=%lf,sec=%lf,lng=%lf\r\n",degree,minute,second,*lat);
}
uint8_t Getgps(uint8_t *p,uint8_t sta)
{
	int a=0;
	char	*adr;
	static double tempScourse=0,templat=0,templng=0;
	if(sta==1)
	{
		a+=sscanf((const char*)p,"$GPGGA,%*[^,],%lf,N,%lf,E",&templat,&templng);
		adr=strstr((const char*)p,"SOL_COMPUTED");
		a+=sscanf(adr,"%*[^,],%*[^,],%*[^,],%lf",&tempScourse);						//%*[A-Z]����NARROW_INT,%*[0-9]������һ������
	}
	else if(sta==0)
	{
		//a=sscanf((const char*)p,"Cordinate%lf,N,%lf,E,%lf",&lat1,&lng1,&sCourse);
		a=sscanf((const char*)p,"Cordinate%lf,N,%lf,E,%lf",&templat,&templng,&tempScourse);
	}
	
		if((tempScourse<=360&&tempScourse>=0))					//����gps������ʱ��ͻȻ����ƫ�������ת�����ԽǶ�˲ʱ�仯45�����ϵ����ݲ�����
		{
			if(fabs(tempScourse-sCourse)>=180)
			{
				if(((360.0f-fabs(tempScourse-sCourse))<45.0f)||sCourse==0)sCourse=tempScourse;
			}
			else
			{
				sCourse=tempScourse;
			}
		}
		gpsTransform(&templng,&templat);
		if((fabs(templat-lat1)<0.01f)||(lat1==0))lat1=templat;
		if((fabs(templng-lng1)<0.01f)||(lng1==0))lng1=templng;
		printf("Cordinate%lf,N,%lf,E,%lf\r\n",lat1,lng1,sCourse);
		if(a==3)
			return 1;
		else 
			return 0;

}

uint8_t SetOppositeGps(uint8_t *p)
{
	int a;
	a=sscanf((const char*)p,"SET,N,%lf,E,%lf",&lat2,&lng2);
	if(a==2)
	{
		return 1;
	}
	else
		return 0;
}

void ReadGps()
{
	printf("ln1=%lf,la1=%lf,ln2=%lf,la2=%lf\r\n",lng1,lat1,lng2,lat2);
}

void Write_Coordinates(double AW,double AJ)//��һ�β���2048
{
	uint32_t temp_Aw	=	0,temp_Aj=0;
	temp_Aw	=	AW*1000000;
	temp_Aj	=	AJ*1000000;
	Flash_wirte(Flash_Lat_Addr,(uint8_t*)&temp_Aw,0);
	delay_ms(10);
	Flash_wirte(Flash_Lng_Addr,(uint8_t*)&temp_Aj,0);
}

uint8_t  isConnected()
{	
	static uint8_t times=0;
	if(USART_RX_STA&0x10000)
	{
		times++;
	  if(strstr((char*)USART_RX_BUF, "GPGGA") != NULL&&strstr((char*)USART_RX_BUF, "HEADINGA") != NULL)
		{
			times++;
			
		}
		if(times>10)
		{
			times=0;
			return 1;
		}
		USART_RX_STA=0;
		memset(USART_RX_BUF,0,strlen((const char*)USART_RX_BUF));	
	}
		return 0;
}

void Read_Coordinates(double *AW,double *AJ)
{
		uint32_t temp_Aw	=	0,temp_Aj=0;
		temp_Aw=Flash_ReadWord(Flash_Lat_Addr);
		delay_ms(10);
		temp_Aj=Flash_ReadWord(Flash_Lng_Addr);
		if(temp_Aw==0xFFFFFFFF)
		{
			temp_Aw	=	0;
		}
		if(temp_Aj==0xFFFFFFFF)
		{
			temp_Aj	=	0;
		}
	*AW=((double)temp_Aw)/1000000.0;
	*AJ=((double)temp_Aj)/1000000.0;
//	*AW=Flash_ReadWord(0);
//	*AJ=Flash_ReadWord(2);
}
