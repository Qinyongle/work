#ifndef _main_h_
#define _main_h_
#include "stm32f10x_gpio.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "usart.h"
#include "motor.h" 
#include "Dog.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"
#include "flash.h"
#include "interface.h"
#include "Time.h"
#include "gps.h"
#include "cevent.h"
#include "cpost.h"
#include "myevent.h"


#define BOARD "control-Gps V1"
#define VERSION "6.2.0"
#define TIME "2022.11.30"
enum BORDMOdE
{
	CheckMode,
	GPSCheck,
	UsartMode,
	BugMode,
};

#endif