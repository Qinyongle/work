#include "light_Coupler.h"
#include "stdio.h"
#include "motor.h"
#include "delay.h"
#include "interface.h"
float mod_buffer[9]={0,45,90,135,180,225,270,315,360};			
int8_t Scale=invalid;
int8_t  motor.Direction=0;
uint8_t period=0;					//����
int32_t curentPosion=0;
uint8_t Refresh=0;			//ˢ�¹���
uint8_t lastScale=0,beforeLastScale=0;
struct LIGHTCOUPLER *lc_buffer_positive[lc_Num]={0};				//����

uint8_t BUG=0;

uint8_t GetSerialNum( struct LIGHTCOUPLER *lighCoup)
{
 if(lighCoup==NULL)
 {
	 return invalid;
 }
 return lighCoup->Serial_Number;
}
 
uint8_t GetStatus( struct LIGHTCOUPLER *lighCoup)
{
	 if(lighCoup==NULL)
	 {
		 return INVALID;
	 }
	 return GPIO_ReadInputDataBit(lighCoup->Port,lighCoup->Pin);
}


struct LIGHTCOUPLER *light_Coupler_New(uint8_t Serial_Number,GPIO_TypeDef *Port,	uint32_t Pin)
{
  struct LIGHTCOUPLER *p=( struct LIGHTCOUPLER *)malloc(sizeof( struct LIGHTCOUPLER));
	p->Serial_Number=Serial_Number;
	p->Port=Port;
	p->Pin=Pin;
	p->GetSerialNum=GetSerialNum;
	p->GetStatus=GetStatus;
	return p;
}

void light_Coupler_Init()
{
	uint8_t i;
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//ʹ��PORTA,PORTEʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);//ʹ��PORTA,PORTEʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTA,PORTEʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);						 //Ҫ�ȿ�ʱ�ӣ�����ӳ�䣻����ʾ�ر�JTAG,ʹPB3��PB4����ͨIO��
	lc_buffer_positive[0]=light_Coupler_New(lc0,lc0_Port,lc0_Pin);
	lc_buffer_positive[1]=light_Coupler_New(lc1,lc1_Port,lc1_Pin);
	lc_buffer_positive[2]=light_Coupler_New(lc2,lc2_Port,lc2_Pin);
	lc_buffer_positive[3]=light_Coupler_New(lc3,lc3_Port,lc3_Pin);
	lc_buffer_positive[4]=light_Coupler_New(lc4,lc4_Port,lc4_Pin);
	lc_buffer_positive[5]=light_Coupler_New(lc5,lc5_Port,lc5_Pin);
	lc_buffer_positive[6]=light_Coupler_New(lc6,lc6_Port,lc6_Pin);
	lc_buffer_positive[7]=light_Coupler_New(lc7,lc7_Port,lc7_Pin);
	lc_buffer_positive[8]=light_Coupler_New(lc8,Check_Port,Check_Pin);
	for(i=0;i<lc_Num;i++)
	{
		 GPIO_InitStructure.GPIO_Pin = lc_buffer_positive[i]->Pin;								 
		 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 
		 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
		 GPIO_Init(lc_buffer_positive[i]->Port, &GPIO_InitStructure);		
	}
}

void scanLighCoup()
{
	uint8_t i,j;
	uint8_t statusCount=0;
	int8_t tempScale=0;
	
	for(i=0;i<lc_Num-1;i++)
	{
		if(lc_buffer_positive[i]->GetStatus(lc_buffer_positive[i])==OFF)
		{
			if(lc_buffer_positive[i]->GetStatus(lc_buffer_positive[i])==OFF)
			{
			tempScale=lc_buffer_positive[i]->GetSerialNum(lc_buffer_positive[i]);
	//printf("tempScale=%d,Scale=%d\r\n",tempScale,Scale);
				if(motor.Direction==1)
				{
					
					if((Scale==0)&&(tempScale==7))
					{
						BUG|=0x01;
						return;	
					}						//�����һ�ε�Scale��0���������ת��ʱ��tempScaleΪ7��ʾת�̵������󴥷��˹�����ι��������
				}
				else if(motor.Direction==-1)
				{
					
					if((Scale==7)&&(tempScale==0))
					{
						BUG|=0x02;
						return;	
					}				
				}
				
				if(abs(tempScale-Scale)>=3&&abs(tempScale-Scale)<5)return;
				if(Refresh==1)
				{
					lastScale=Scale;
					Scale=lc_buffer_positive[i]->GetSerialNum(lc_buffer_positive[i]);
					Refresh=0;
					curentPosion=getAngle();					//��ȡ��⵽�ĽǶ�
					motor.Pulse_Inground=0;
					//printf("scale=%d,curentPosion=%d,position=%lf\r\n",Scale,curentPosion,curentPosion*STEP_ANGLE);
				}
				

//				lastScale=Scale;
//				Scale=lc_buffer_positive[i]->GetSerialNum(lc_buffer_positive[i]);
//				if(Refresh==1)
//				{
//					Refresh=0;
//					curentPosion=getAngle();					//��ȡ��⵽�ĽǶ�
//					motor.Pulse_Inground=0;
					//RefreshAngle();
					//printf("scale=%d,curentPosion=%d,position=%lf\r\n",Scale,curentPosion,curentPosion*STEP_ANGLE);
//			}
				}
		}
		else if(lc_buffer_positive[i]->GetStatus(lc_buffer_positive[i])==ON)
		{	
			if(lc_buffer_positive[i]->GetStatus(lc_buffer_positive[i])==ON)
			{
				statusCount++;
				if(statusCount==lc_Num-1)
				{
					//printf("statusCount=%d\r\n",statusCount);
					Refresh=1;
				}
				//Scale=invalid;
			}
		 }
	}
}


void RefreshCurPositon(int32_t * position)
{
		float tempAngle;
	//	printf("motor.Direction=%d,period=%d,Scale=%d\r\n",motor.Direction,period,Scale);
		if(motor.Direction==-1)				//��ָ��λ��0���ʱ�����������ת��ǰ���Ϊ360��
		{
			if(period==0&&Scale==0)
				{
					period=9;
					*position=(cycle*period+((float)Scale*gapAngle))/STEP_ANGLE;
					//Scale=7;
				}
		}
		//printf("motor.Direction=%d,period=%d,Scale=%d\r\n",motor.Direction,period,Scale);
}
	
int32_t getAngle()
{
	int32_t tempAngle;
	if(motor.Direction==1)				//����ת����
	{
		if(((lastScale==5)||(lastScale==6)||(lastScale==7))&&((Scale==0)||(Scale==1)||(Scale==2)))				//���ԭ������Ƿ񱻴�����������˵��ָ���Ѿ�ת����һ������45�㣬�������ڼ���+1
			{
					period++;
					if(period>=nPointer)
					{
						period=nPointer;
					}
			}
			else if(Scale!=0)
			{             
				if(period==nPointer)
				{
					period=0;
				}
			}
			tempAngle=(cycle*period+((float)Scale*gapAngle))/STEP_ANGLE;
	}
	else if(motor.Direction==-1)				//��ָ���Ѿ�ת����360��ʱ�򣬷�����תʱ������Ҫ��һ��
	{
			if(((lastScale==0)||(lastScale==1)||((lastScale==2)))&&((Scale==7)||(Scale==6)||(Scale==5)))
			{
				if(period==0)
					period=8;
				else
					period--;
			}
			else if(period==0&&Scale==0)
			{
				period=nPointer;
			}
			tempAngle=(cycle*period+((float)Scale*gapAngle))/STEP_ANGLE;
	}
	if(CouplerLog)
	{
		printf("motor.Direction=%d,period=%d,Scale=%d\r\n",motor.Direction,period,Scale);
	}
	return tempAngle;
}



/*�������ʱ���Ƕ��Ƿ�ƫ��*/
void angleRef(int32_t *value)
{
		if((lc_buffer_positive[0]->GetStatus(lc_buffer_positive[0])==SET)&&(lc_buffer_positive[8]->GetStatus(lc_buffer_positive[8])==SET))
		{
			if((lc_buffer_positive[0]->GetStatus(lc_buffer_positive[0])==SET)&&(lc_buffer_positive[8]->GetStatus(lc_buffer_positive[8])==SET))
			{
					if(period!=nPointer)
					{
						period=nPointer;
						motor.Pulse_Inground=0;
						Scale=0;
						*value=(cycle*period)/STEP_ANGLE;
					}
			}
	}			
}