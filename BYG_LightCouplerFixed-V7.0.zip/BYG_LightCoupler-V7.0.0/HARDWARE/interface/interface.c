#include "interface.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "motor.h"
#include "gps.h"
#include "cevent.h"
#include "cpost.h"
#include "myevent.h"


double longitude=0,latitude=0;

float azimuth_Angle=0;


uint8_t Log=0;
uint8_t GpsLog=0;
uint8_t Usart1Log=0;
uint8_t CouplerLog=0,GetGpsFlag=1,Usart2Logon=0;


void Usart3_Process()
{

	double angle=0;
	int32_t deltaAngle;
	if(USART3_RX_STA&0x8000)
	{
		    USARTN=USART3;

		 if(USART3_RX_BUF[0] == 'A' && strchr((char*)USART3_RX_BUF, 'B') != NULL)		
		{
					if(motor.Cal_Pulse==0)
					{
					angle=atof((const char*)USART3_RX_BUF+1);				//�ַ���ת���ɸ���������	
					motor.Target_Pulse	=	((angle*10)/STEP_ANGLE);		//����Ƕ�����Ҫ��������
					if((motor.Target_Pulse%10)>=5)																		//��������
					{
						motor.Target_Pulse	=((motor.Target_Pulse+10)/10);
					}
					else
					{
						motor.Target_Pulse = (motor.Target_Pulse/10);
					}
					angle=CompensateAngle(motor.Target_Pulse*STEP_ANGLE);
					
					printf("angle=%lf\r\n",angle);
					motor.Target_Pulse=angle/STEP_ANGLE;

					deltaAngle=motor.Target_Pulse-motor.Current_Pulse;
					if(deltaAngle>OneCircleNums>>1)
					{
						deltaAngle -=OneCircleNums;
					}
					else if(deltaAngle<-OneCircleNums>>1)
					{
						deltaAngle +=OneCircleNums;
					}
					printf("Angle=%lf,motor.Target_Pulse=%d,motor.Current_Pulse=%d\r\n",deltaAngle*STEP_ANGLE,motor.Target_Pulse,motor.Current_Pulse);
					if(deltaAngle>0)
					{
						SET_LEFT;	
						motor.Direction=1;
					}
					else if(deltaAngle<0)
					{
						SET_RIGHT;	
						motor.Direction=-1;
					}
				}
				else
				{
					my_printf(3,"pulse=%d\r\n",motor.Target_Pulse);
				}
		}
		else if(strstr((char*)USART3_RX_BUF, "MotorFixed") != NULL)	
		{
			int temp;
			sscanf((char*)USART3_RX_BUF,"MotorFixed(%d)",&temp);
			if(temp==0||temp==1)
			motor.Fixed=temp;
			printf("MotorFixed=%d\r\n",motor.Fixed);
			
			boardConfig.FixedFlag=motor.Fixed;
			boardConfig.configStatus=CONFIG_COMMIT;
			
		}
	 else if(strstr((char*)USART3_RX_BUF, "ReadGps") != NULL)					//��Gps
		{
				ReadGps();
		}
		else  if(strstr((char*)USART3_RX_BUF, "SET") != NULL)						//���öԷ���γ��
		{
			if(SetOppositeGps(USART3_RX_BUF)==1)
			{
				boardConfig.latitude=lat2;
				boardConfig.longitude=lng2;
				boardConfig.configStatus=CONFIG_COMMIT;
//				Write_Coordinates(lat2,lng2);				//�������õľ�γ��
//				Read_Coordinates(&lat2,&lng2);
				my_printf(3,"ln1=%lf,la1=%lf,ln2=%lf,la2=%lf\r\n",lng1,lat1,lng2,lat2);
				//printf("Set Success\r\n");
			}
			else
			{
				my_printf(3,"Set Fail\r\n");
			}
		}
		else if(strstr((char*)USART3_RX_BUF, "Calibrate") != NULL)							//�޸��ٶ�
		{
			int32_t temp_cali=0;
			sscanf((char*)USART3_RX_BUF,"Calibrate%d",&temp_cali);
			motor.Calibrate=temp_cali&0x01;
			
			boardConfig.Calibrate=motor.Calibrate;
			boardConfig.configStatus=CONFIG_COMMIT;
		}
		else if(strstr((char*)USART3_RX_BUF, "Reset") != NULL)							
		{
				NVIC_SystemReset();
		}
		else if(strstr((char*)USART3_RX_BUF, "Compensation") != NULL)					//���ò�����
		{
			sscanf((char*)USART3_RX_BUF,"Compensation%lf",&compensateAngle);
			
			boardConfig.Compensation=compensateAngle;
			boardConfig.configStatus=CONFIG_COMMIT;
//			writeCompensation(compensateAngle);
//			readCompensation(&compensateAngle);
			my_printf(3,"Compensation%lf\r\n",compensateAngle);
		}
		else if(strstr((char*)USART3_RX_BUF, "ReadCompensation") != NULL)		//��������
		{
			my_printf(3,"Compensation%lf\r\n",compensateAngle);
		}
		else if(strstr((char*)USART3_RX_BUF, "logon") != NULL)							
		{
				Log=1;
				my_printf(3,"Log=%d\r\n",Log);
		}
		else if(strstr((char*)USART3_RX_BUF, "logoff") != NULL)							
		{
				Log=0;
				my_printf(3,"Log=%d\r\n",Log);
		}
		else if(strstr((char*)USART3_RX_BUF, "GpsLogon") != NULL)							
		{
				GpsLog=1;
		}
		else if(strstr((char*)USART3_RX_BUF, "GpsLogoff") != NULL)							
		{
				GpsLog=0;
		}
		else if(strstr((char*)USART3_RX_BUF, "UsarLogon") != NULL)							
		{
				Usart1Log=1;
		}
		else if(strstr((char*)USART3_RX_BUF, "UsarLogoff") != NULL)							
		{
				Usart1Log=0;
		}
				else if(strstr((char*)USART3_RX_BUF, "Usart2Logon") != NULL)							
		{
				Usart2Logon=1;
		}
		else if(strstr((char*)USART3_RX_BUF, "Usart2Logoff") != NULL)							
		{
				Usart2Logon=0;
		}
		else  if(strstr((char*)USART3_RX_BUF, "message") != NULL)				//�����ĺ����������֮��ķ�λ��
		{
			my_printf(3,"tCourse=%lf\r\n",tCourse);
			my_printf(3,"sCourse=%lf\r\n",sCourse);
			nmea_GpsInfo_Printf(&GPSinfo);
		}
		else  if(strstr((char*)USART3_RX_BUF, "CouplerOn") != NULL)				
		{
				CouplerLog=1;
		}
		else  if(strstr((char*)USART3_RX_BUF, "CouplerOff") != NULL)				
		{
				CouplerLog=0;
		}
		else  if(strstr((char*)USART3_RX_BUF, "Gps_testFlagOff") != NULL)				
		{
				my_printf(3,"Off\r\n");
				Gps_testFlag=0;
		}
		else  if(strstr((char*)USART3_RX_BUF, "Gps_testFlagOn") != NULL)				
		{
				my_printf(3,"ON\r\n");
				Gps_testFlag=1;
		}
		else  if(strstr((char*)USART3_RX_BUF, "GetGpsOn") != NULL)				
		{
				GetGpsFlag=1;
				boardConfig.GpsFlag=GetGpsFlag;
				boardConfig.configStatus=CONFIG_COMMIT;
		}
		else  if(strstr((char*)USART3_RX_BUF, "GetGpsOff") != NULL)				//�����ĺ����������֮��ķ�λ��
		{
				GetGpsFlag=0;
				boardConfig.GpsFlag=GetGpsFlag;
				boardConfig.configStatus=CONFIG_COMMIT;
		}
		else if(strstr((char*)USART3_RX_BUF, "Apploade") != NULL)
		{
			Flag_Update=0x66;							//��������±�־λ��0x66,��Bootloade�������б���Ҫ���³���
			Flash_wirte(Flag_Update_Addr,(u8 *)&Flag_Update,Half_Word);	//���浱ǰ��־λ
			Flag_Update_App=0;
			Flash_wirte(Flag_Updata_APP_Addr,(u8*)&Flag_Update_App,Half_Word);
														//�˳���ǰwhileѭ��
			NVIC_SystemReset();
		}
		USART3_RX_STA	=	0;																								//����ձ�־λ
		memset(USART3_RX_BUF,0,strlen((const char*)USART3_RX_BUF));										//�建����
	}
}
void Usart_Process()
{
	if(USART_RX_STA&0x10000)
	{
		if(Usart1Log==1)
		{
			my_printf(3,"%s\r\n",USART_RX_BUF);
		}
	  if(strstr((char*)USART_RX_BUF, "GPGGA") != NULL&&strstr((char*)USART_RX_BUF, "HEADINGA") != NULL)
		{
			if(GetGpsFlag==1)
			{
				if(Getgps(USART_RX_BUF,1)==1)			//����������ȷִ��
					{
						cpost(antTracker);
						//ceventPost(EVENT_MOTOR_DRIVE);
					}
			}
		}
		USART_RX_STA	=	0;																								//����ձ�־λ
		memset(USART_RX_BUF,0,strlen((const char*)USART_RX_BUF));										//�建����
	}   
}
void Usart2_Process()
{
	double tempAngle=0;
	
	if(USART2_RX_STA&0x8000)
	{
		if(Usart2Logon)
		{
			my_printf(3,"%s\r\n",USART2_RX_BUF);
		}
			if( strstr((char*)USART2_RX_BUF, "Angle")!= NULL)
			{
				sscanf((const char*)USART2_RX_BUF,"Angle=%lf",&tempAngle);
				motor.Current_Position=tempAngle/STEP_ANGLE;										//ת��������

				motor.Pulse_Inground=0;
			}
			else if(strstr((char*)USART2_RX_BUF, "CheckMode Start") != NULL)	
			{
			  	cpost(CheckZero, .attrs.flag=CPOST_FLAG_CANCEL_CURRENT);  //ж��У�麯��
		  		my_printf(3,"Check Start\r\n");		
					SET_LEFT;							
					motor.Direction=1;
					motor.Cal_Pulse=3*OneCircleNums;
			}
			else if(strstr((char*)USART2_RX_BUF, "Check Success") != NULL)
			{
					my_printf(3,"Check Success\r\n");
					motor.Cal_Pulse=0;
					motor.Pulse_Inground = 0;			//���ۼ�����
					motor.Current_Pulse=0;				//��ʼ����ǰ�Ƕ�
					motor.Motor_Speed=MORTOR_MIN_SPEED_LIMIT;
					ceventPost(EVENT_AFTER_CHECK_INIT);
					cpost(Pid_fun,.attrs.flag=CPOST_FLAG_CIRCULAR,.delay=50);						
					cpost(GPS_init,.attrs.flag=CPOST_FLAG_CIRCULAR,.delay=1000);	  //����pid������
			}
					USART2_RX_STA	=	0;																							//����ձ�־λ
					memset(USART2_RX_BUF,0,strlen((const char*)USART2_RX_BUF));			
	}
}


