#ifndef _flash_h_
#define _flash_h_
#include "stm32f10x_flash.h"
#define start_sddress     0x801E800			//�洢��ʼ��ַ

typedef enum configStatus_t
{
    CONFIG_RESTORE = 0,
    CONFIG_OK,
    CONFIG_COMMIT
} configStatus_t;


typedef struct Config_t
{
	configStatus_t configStatus;
	uint8_t  GpsFlag;
	
	uint16_t Speed;
	double   latitude;
	double   longitude;
	double   Compensation;
	uint32_t tarAngle;
	uint8_t FixedFlag;
	uint8_t Calibrate;
	
} BoardConfig_t;

extern BoardConfig_t boardConfig;


void Flash_wirte(uint32_t ADDR,uint8_t *buff,uint8_t Word_flag);
uint32_t Flash_ReadWord(uint32_t address);
uint16_t Flash_Read(uint32_t address);
void Set_Protection(void);
void Reset_Protection(void);
void Config();
void Flash_put(int idx, BoardConfig_t boardConfig);
void reconfig();
enum Word_E
{
	Word= 0,
	Half_Word
};
#endif
