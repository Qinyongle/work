#ifndef __PTZ_CONTROL_H
#define __PTZ_CONTROL_H

#include "stm32f10x.h"
#include <stdio.h>


char checkSum(char buf[]);
int16_t RX_data(void);

//void Show_horizontal_angle(int16_t step);
//void Show_vertical_angle(int16_t step);
#endif

