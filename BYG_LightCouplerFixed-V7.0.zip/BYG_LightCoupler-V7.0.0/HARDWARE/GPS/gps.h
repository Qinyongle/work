#ifndef _gps_h_
#define _gps_h_
#include "stdint.h"
#define PI 3.1415926
#define R 6371


#define NMEA_MAXSAT         (12)
typedef  enum
{
	init,
	init_success,
	init_failed,
}GPS_STATUS;



typedef struct
{
	uint8_t Hours;
	uint8_t Minute;
	uint8_t Seconds;
}TIME_STRUCT;


typedef struct _nmeaGPGGA
{
	double  lat;        /**< Latitude in NDEG - [degree][min].[sec/60] */
    char    ns;         /**< [N]orth or [S]outh */
	double  lon;        /**< Longitude in NDEG - [degree][min].[sec/60] */
    char    ew;         /**< [E]ast or [W]est */
    int     sig;        /**< GPS quality indicator (0 = Invalid; 1 = Fix; 2 = Differential, 3 = Sensitive) */
	int     satinuse;   /**< Number of satellites in use (not those in view) */
    double  HDOP;       /**< Horizontal dilution of precision */
    double  elv;        /**< Antenna altitude above/below mean sea level (geoid) */
    char    elv_units;  /**< [M]eters (Antenna height unit) */
    double  diff;       /**< Geoidal separation (Diff. between WGS-84 earth ellipsoid and mean sea level. '-' = geoid is below WGS-84 ellipsoid) */
    char    diff_units; /**< [M]eters (Units of geoidal separation) */
    double  dgps_age;   /**< Time in seconds since last DGPS update */
    int     dgps_sid;   /**< DGPS station ID number */

} nmeaGPGGA;

typedef struct _nmeaHEADINGA
{
	char cal_state[32];
	char pos_type[16];
	double baseline;
	double headingA;
	double pitch;
	double headingA_var;
} nmeaHEADINGA;


/**
 * Information about satellite
 * @see nmeaSATINFO
 * @see nmeaGPGSV
 */
typedef struct _nmeaSATELLITE
{
    int     id;         /**< Satellite PRN number */
    int     in_use;     /**< Used in position fix */
    int     elv;        /**< Elevation in degrees, 90 maximum */
    int     azimuth;    /**< Azimuth, degrees from true north, 000 to 359 */
    int     sig;        /**< Signal, 00-99 dB */

} nmeaSATELLITE;

/**
 * Information about all satellites in view
 * @see nmeaINFO
 * @see nmeaGPGSV
 */
typedef struct _nmeaSATINFO
{
    int     inuse;      /**< Number of satellites in use (not those in view) */
    int     inview;     /**< Total number of satellites in view */
    nmeaSATELLITE sat[NMEA_MAXSAT]; /**< Satellites information */

} nmeaSATINFO;
typedef struct _nmeaINFO
{
    int     smask;      /**< Mask specifying types of packages from which data have been obtained */

	
    int     sig;        /**< GPS quality indicator (0 = Invalid; 1 = Fix; 2 = Differential, 3 = Sensitive) */
    int     fix;        /**< Operating mode, used for navigation (1 = Fix not available; 2 = 2D; 3 = 3D) */

    double  PDOP;       /**< Position Dilution Of Precision */
    double  HDOP;       /**< Horizontal Dilution Of Precision */
    double  VDOP;       /**< Vertical Dilution Of Precision */

    double  lat;        /**< Latitude in NDEG - +/-[degree][min].[sec/60] */
    double  lon;        /**< Longitude in NDEG - +/-[degree][min].[sec/60] */
    double  elv;        /**< Antenna altitude above/below mean sea level (geoid) in meters */

		double headingA;
		double headingA_var;
		double pitch;

    nmeaSATINFO satinfo; /**< Satellites information */

} nmeaINFO;

extern nmeaGPGGA myGPGGA;
extern nmeaINFO GPSinfo;
extern double lng1,lat1,lng2,lat2;
extern double sCourse,tCourse,aCourse,zDegree,deltaDegree;
extern uint8_t Gps_testFlag;

uint8_t Getgps(uint8_t *p,uint8_t sta);
double get_angle(double AW, double Aj, double BW, double Bj);
uint8_t SetOppositeGps(uint8_t *p);
void ReadGps(void);
void Write_Coordinates(double AW,double AJ);
void Read_Coordinates(double *AW,double *AJ);
uint8_t  isConnected(void);
void GPS_init(void);
void nmea_GpsInfo_Printf(nmeaINFO *gps_data);
#endif
