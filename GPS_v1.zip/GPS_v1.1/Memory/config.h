#ifndef config_h
#define config_h

#ifdef __cplusplus
extern "C" {
#endif
/*---------------------------- C Scope ---------------------------*/
#include <stdbool.h>
#include "stdint.h"
#include "stockpile_f103cb.h"
typedef enum configStatus_t
{
    CONFIG_RESTORE = 0,
    CONFIG_OK,
    CONFIG_COMMIT
} configStatus_t;


typedef struct Config_t
{
	configStatus_t configStatus;
	uint8_t Addrh;
	uint8_t Addrl;
	uint8_t Ch;
} BoardConfig_t;

extern BoardConfig_t boardConfig;
void Config();
void Flash_put(int idx, BoardConfig_t boardConfig);

#ifdef __cplusplus
}



#endif
#endif
