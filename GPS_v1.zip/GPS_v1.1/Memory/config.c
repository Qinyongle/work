#include "config.h"
#include <string.h>
#include "stdio.h"
BoardConfig_t boardConfig;
uint8_t flash_Buffer[100]={0};



void init()
{
	memset(flash_Buffer,0,100);
	memcpy(flash_Buffer, (uint8_t*) (STOCKPILE_APP_DATA_ADDR), 100);
}

	
uint8_t flash_Buffer_Read_Byte(uint16_t offset)
{
	return flash_Buffer[offset];
}

void flash_Buffer_Write_Byte(uint16_t offset,uint8_t data)
{
	 flash_Buffer[offset]=data;
}


void Flash_get(int _offset, BoardConfig_t boardConfig)
{
		uint16_t offset = _offset;
		uint8_t* _pointer = (uint8_t*) &boardConfig;

		for (uint16_t count = sizeof(BoardConfig_t); count; --count, ++offset)
		{
				*_pointer++ = flash_Buffer_Read_Byte(offset);
		}
}

void FLASH_Buffer_Flush()
{
	Stockpile_Flash_Data_Empty(&stockpile_data);		//����������
	Stockpile_Flash_Data_Begin(&stockpile_data);		//��ʼд������
	Stockpile_Flash_Data_Write_Data32(&stockpile_data,(uint32_t *)flash_Buffer,sizeof(flash_Buffer)/sizeof(uint32_t));
}


void Flash_put(int idx, BoardConfig_t boardConfig)
{
        uint16_t offset = idx;

        const uint8_t* _pointer = (const uint8_t*) &boardConfig;

        for (uint16_t count = sizeof(boardConfig); count; --count, ++offset)
        {
            flash_Buffer_Write_Byte(offset, *_pointer++);
        }
            // Save the data from the buffer to the flash right away
          FLASH_Buffer_Flush();
}


void Config()
{
	init();
	Flash_get(0,boardConfig);
	printf("boardConfig.Addrh=%c\r\n",boardConfig.Addrh);
	printf("boardConfig.Addrl=%c\r\n",boardConfig.Addrl);
	printf("boardConfig.Ch=%c\r\n",boardConfig.Ch);
	if(boardConfig.configStatus != CONFIG_OK)
	{
		/*boardConfig = BoardConfig_t{
			BoardConfig_t.configStatus = CONFIG_OK,
			BoardConfig_t.AddrH=0xFF,
			BoardConfig_t.Addrl=0xFF,
			BoardConfig_t.Ch=0x0A
		};*/
		
			boardConfig.configStatus = CONFIG_OK;
			boardConfig.Addrh=0x31;
			boardConfig.Addrl=0x32;
			boardConfig.Ch=0x0A;
		Flash_put(0,boardConfig);
	}
}