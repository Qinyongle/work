#ifndef _interface_h_
#define _interface_h_

#define BUFFER_SIZE  300
#define TEMP_SIZE 50

#define long_start	17
#define long_num		15

#define lat_start	32
#define lat_num 16

#define Frame_Length 
extern unsigned char lora_address[];
void onusart();
void Usart_Process(void);
unsigned char isConnected(void);
void send_ToLora(unsigned char *str);
#endif
